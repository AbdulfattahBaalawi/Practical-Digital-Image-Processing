clear
clc
% 1. Write a script that performs the following operations:
% a. Set the value of variables a, b, c1, c2, c3 and x. The values don�t 
%    matter, except you should set c2 to 42.
% b. Save the values of all the variable except x to mydata.mat using the  
%    save operation.
% c. Set the value of c2 to -99
% d. Load myData.mat and check that c2 is now 42.
% e. Clear all variables.
% f. Load myData.mat again and note that the variable x is not present.
a = 1;
b = 2;
c1 = 3;
c2 = 42;
c3 = 4;
x = 5;
save mydata.mat '-regexp' [abc]*
c2 = -99
load 'mydata.mat'
c2
clear
load 'mydata.mat'
a
b
c1
x
