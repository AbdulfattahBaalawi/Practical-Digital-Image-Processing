function test
    clc
% 3. Write a function called genStats that will compute statistics for a 
%    set of class grades. The grades will be stored in a spread sheet and 
%    your function will compute statistics and then write the grades along 
%    with the statistics to another spread sheet.
%    You may assume that the initial spread sheet will have a format 
%    similar too:
%         Student Name Exam1 Exam2 Exam3 ...
%         student 1 100 76 45 ...
%         student 2 34 83 89 ...
% The first row is the header row and the first column is the list of 
%    student names. There may be any number of exam grades and there may be 
%    any number of students. Although, you may assume that there will be at 
%    least one student and that there will be at least one exam.
%    Also, every student will have a grade for every exam.
%    Your function should only have one input (a string containing the 
%    file name of the grades file) and no outputs.
%    You must write your function to perform the following steps:
%    a. Calculate the average grade of each student (across the rows) and 
%       store it in a new column called 'Average' (to the right of the last 
%       exam grade) .
%    b. Calculate the deviation of each student's overall average (calculated 
%       in step a) from the maximum student average and store it in a new 
%       column called 'Deviation' (to the right of the 'Average' column). 
%    Note that deviation is just the difference between the maximum student 
%    average and a student's overall average.
%    c. Calculate the average of each column's data (each exam, the averages 
%       calculated in step a, and the deviations calculated in step b, then 
%       store these averages below the last row of the original data and
%       name that row 'Total Average'.
%    d. Write the original data along with all of the new data to a file 
%       named �Stats_<name_of_original_file>' (so if the inputted file name 
%       was 'Student_Grades.csv', the new data would be written to the file 
%       named 'Stats_Student_Grades.csv').
%    e. Construct a spread sheet with suitable test data and use it to test 
%       your function.
    ca = {'Name','exam 1','exam 2','exam 3','exam 4','exam 5';
          'Joe', 0, 0, 0, 0, 0;
          'Sally', 0, 0, 0, 0, 0;
          'Fred', 0, 0, 0, 0, 0;
          'Sue', 0, 0, 0, 0, 0;
          'Betty', 0, 0, 0, 0, 0;
          'John', 0, 0, 0, 0, 0;
          'Ann', 0, 0, 0, 0, 0;
          'Pat', 0, 0, 0, 0, 0};
      for row = 2:9
          for col = 2:6
              grade = floor(rand(1,1)*100);
              ca{row,col} = grade;
          end
      end
      xlswrite('grades.xls', ca)
      genStats('grades.xls')
end

function genStats(name)
    [nums txt raw] = xlsread(name);
    [rows cols] = size(raw);
    raw{1, cols+1} = 'Average';
    mxAvg = 0;
    for r = 1:(rows-1)
        avg = mean(nums(r, 2:end));
        raw{r+1, cols+1} = avg;
        if avg > mxAvg, mxAvg = avg; end
    end
    raw{1, cols+2} = 'Deviation';
    for r = 1:(rows-1)
        raw{r+1, cols+2} = mxAvg - raw{r+1, cols+1};
    end
    raw{rows+1,1} = 'Total Average';
    for col = 2:cols
        avg = mean(nums(1:end,col-1));
        raw{rows+1, col} = avg;
    end
    xlswrite(['Stats_' name], raw)
end

