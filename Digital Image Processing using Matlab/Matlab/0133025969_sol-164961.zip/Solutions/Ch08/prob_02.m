function test
    clc
% 2. One requirement for all freshmen classes is an issue of a 'Standing' 
%    during the middle of the term. The results are either a Satisfactory  
%    (S) or Unsatisfactory (U). Since you are the office employee in charge  
%    of issuing these grades you decide to write a function called  
%    midtermGrades to help you. You discover that the grades are on a
%    spreadsheet organized like this:
%    � Each student is represented by one row on the spreadsheet.
%    � Unfortunately, since these sheets are created by different  
%      instructors, they are not necessarily consistent in their layout.
%    � The first row will contain the following 6 strings in any order:
%      'name', 'math', 'science', 'english', 'history' and 'cs'.
%    � Under the name column will be a string with the student�s name.
%    � Grades in the other columns can be 'A', 'B', 'C', 'D', 'F', or 'W'.
%    � A student�s grade is �S� if there are more A�s, B�s and C�s than not.
%    Your function should print out grades ready to be entered consisting  
%    of a table with headings 'Name' and 'S/U'
    ca = {'name','english','cs','math','history','science';
          'Joe','A','A','A','A','A';
          'Sally','A','A','A','A','A';
          'Fred','A','A','A','A','A';
          'Sue','A','A','A','A','A';
          'Betty','A','A','A','A','A';
          'John','A','A','A','A','A';
          'Ann','A','A','A','A','A';
          'Pat','A','A','A','A','A'};
      for row = 2:9
          for col = 2:6
              letter = char('A' + floor(rand(1,1)*5));
              if letter == 'E', letter = 'F'; end
              ca{row,col} = letter;
          end
      end
      xlswrite('grades.xls', ca)
      midtermGrades('grades.xls')
end

function midtermGrades(name)
    [~, txt] = xlsread(name);
    [rows cols] = size(txt);
    for ndx = 1:cols
        if strcmp(txt{1,ndx}, 'name'), nameCol = ndx; end
    end
    fprintf('Name\tS/U\n')
    for row = 2:rows
        good = 0;
        for col = 1:cols
            if col ~= nameCol
                if txt{row,col} < 'D', good = good+1; end
            end
        end
        if good > (cols-good-1), letter = ' S';
        else letter = ' U'; end
        name = txt{row, nameCol};
        if length(name) < 4, name = [name ' ']; end
        fprintf('%s\t%s\n', name, letter)
    end
end

