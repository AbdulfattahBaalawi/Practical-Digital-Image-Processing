function test
    clc
% 4. Write a function called replaceStr. Your function should take in the 
%    following (in this order):
%        filename: A string that corresponds to the name of a file
%           wordA: A string that is a word (contains no spaces)
%           wordB: Another string that is also a word (contains no spaces)
%    Your function should do the following:
% a. Read the file a line at a time.
% b. On each line, replace every occurrence of wordA with wordB.
% c. Write the modified text file with the same name as the original file,  
%    but preprended with 'new_'. For instance, if the input filename was  
%    'data.txt', the output filename would be 'new_data.txt'.
% d. Prepare a test file by downloading a text file from the Internet.  
%    For example, the complete works of Shakespeare are accessible at  
%    http://www.william-shakespeare.info
% e. Examine the file for repeated words and test your function by writing  
%    a script that replaces frequently repeated words
    replaceStr('declaration.txt', 'right', 'preference')
end

function replaceStr(name, from, to)
    in = fopen(name, 'r');
    out = fopen(['new_' name], 'w');
    line = '';
    while ischar(line) 
        line = fgetl(in);
        if ischar(line)
            while length(line) > 0
                [token line] = strtok(line,' ,.;:!?');
                punct = ' ';
                if length(line) > 0 && line(1) ~= ' '
                    punct = [line(1) punct];
                end
                if strcmpi(token, from)
                    up = isUpper(token(1));
                    token = to;
                    if up, token(1) = token(1) + 'A' - 'a'; end
                end
                fprintf(out, '%s%s', token, punct);
            end
            fprintf(out, '\n');
        end
    end
end

function res = isUpper(ch)
    res = ch >= 'A' && ch <= 'Z';
end
        
        