function test
    clc
% 2. Write a recursive function called oddfact(n) which takes in a number 
%    and returns the factorial of the odd numbers between the given number  
%    and 1.  
%    For example:
oddfact(4) % returns 3
oddfact(9) % returns 945 = 9*7*5*3*1
end

function res = oddfact(N)
    if N == 1, res = 1;
    elseif mod(N,2) == 0
        res = oddfact(N-1);
    else
        res = N * oddfact(N-2);
    end
end

