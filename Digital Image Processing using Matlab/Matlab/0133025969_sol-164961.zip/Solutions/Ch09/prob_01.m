function test
    clc
% 1. For this problem you will be required to write three functions: 
%    recurSum, recurProd and fibVector. The first one will take in a vector 
%    and compute the sum of the elements of the vector. The second one will 
%    take in a vector and compute the product of the elements of the vector. 
%    The third one will take in a number, N, and return a vector containing 
%    the first N terms of the Fibonacci sequence. You must use recursion to 
%    complete these functions. You may not use for loops, while loops or the 
%    functions sum, prod or factorial. Your function headers should be:
%              function ans = recurSum(arr)
%              function ans = recurProd(arr)
%              function vec = fibVector (num)
    N = floor(rand(1,1) * 30 + 5);
    vec = ceil(rand(1,N) * 100)
    matSum = sum(vec)
    mySum = recurSum(vec)
    matProd = prod(vec)
    myProd = recurProd(vec)
    fibV = fibVector(N)
end

function ans = recurSum(arr)
    if length(arr) == 0
        ans = 0;
    else
        ans = arr(1) + recurSum(arr(2:end));
    end
end


function ans = recurProd(arr)
    if length(arr) == 0
        ans = 1;
    else
        ans = arr(1) * recurProd(arr(2:end));
    end
end


function res = fibVector(num)
    if num == 1, res = 1;
    elseif num == 2, res = [1 1];
    else
        v = fibVector(num-1);
        res = [v v(end-1 )+ v(end)];
    end
end
