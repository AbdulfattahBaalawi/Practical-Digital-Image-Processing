function test
clc
% 4. Write a function called classAverage that takes in an array of numbers  
%    and, after normalizing the grades in such a way that the highest  
%    corresponds to 100, (see Chapter 3, Problem 5) returns the letter  
%    grade of the class average. The grade ranges are as follows:
            % average>90 => A
            % 80<=average<90 => B
            % 70<=average<80 => C
            % 60<=average<70 => D
            % average<60 => F
% For example, 
classAverage( [70 87 95 80 80 78 85 90 66 89 89 100] ) % should return B
classAverage( [50 90 61 82 75 92 81 76 87 41 31 98] ) % should return C
classAverage( [10 10 11 32 53 12 34 74 31 30 26 22] ) % should return F
end

function letter = classAverage(tests)
    maxv = max(tests);
    normTests = tests .* 100 ./ maxv;
    avg = mean(normTests);
        if avg >= 90, letter = 'A';
    elseif avg >= 80, letter = 'B';
    elseif avg >= 70, letter = 'C';
    elseif avg >= 60, letter = 'D';
                 else letter = 'F';
        end
end
