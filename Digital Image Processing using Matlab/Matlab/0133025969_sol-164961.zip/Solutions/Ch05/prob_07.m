function test
clc
% 7. Given an array of numbers that could be negative, write a function 
%    posavg(a) to calculate and return the average (mean) of the 
%    non-negative numbers in the single dimensional array,  a. 
%    One such solution is mean(a(find(a>0))). 
%    In order to test your understanding of class concepts, re-implement 
%    the posavg(a) function using iteration. You may not use the built-in 
%    functions sum(...), find(...), or mean(...) in your solution.
    for ndx = 1:5
        N = ceil(rand(1,1)*10) + 10;
        mx = rand(1,1)*200;
        V = ceil((rand(1,N)-0.5) .* mx)
        pavg = posavg(V)
    end
end

function pav = posavg(a)
    total = 0;
    N = 0;
    for val = a
        if val > 0
            total = total + val;
            N = N + 1;
        end
    end
    pav = total / N;
end
