function test
clc
% 2. Write and test the code for the function mysteryFunction that consumes  
%    a vector, V, and produces a new vector, W, of the same length where  
%    each element of W is the sum of the corresponding element in V and  
%    the previous element of V. Consider the previous element of V(1)  
%    to be 0. For example,
mysteryFunction( 1:8 ) % should return [1 3 5 7 9 11 13 15]
mysteryFunction([1:6].^2) % should return [1 5 13 25 41 61]
% Hint: mod(x, y) gives the remainder when x is divided by y.
end

function W = mysteryFunction(V) 
    vp = [0 V(1:end-1)];
    W = V + vp;
end

