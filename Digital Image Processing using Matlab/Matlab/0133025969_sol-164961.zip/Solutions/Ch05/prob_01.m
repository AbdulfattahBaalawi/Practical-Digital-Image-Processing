function test
clc
% 1. Write a function called checkFactor that takes in two numbers, and 
%    checks if they are divisible, i.e. if the first is divisible by the  
%    second. You may assume that both numbers are positive. Your function  
%    should return a logical value, true or false. For example,
checkFactor(25,6) % should return false.
checkFactor (9,3) % should return true.
checkFactor (3,9) % should return false.
end

function res = checkFactor(a, b)
    res = mod(a, b) == 0;
end
