clear
clc
% 4. Write a script that validates the relationship between sin u, cos u,
% and tan u by evaluating these functions at suitably chosen values
% of u.
u = 0
diff = sin(u)./cos(u) - tan(u)
u = pi./3
diff = sin(u)./cos(u) - tan(u)
u = 2.*pi./3
diff = sin(u)./cos(u) - tan(u)
u = pi
diff = sin(u)./cos(u) - tan(u)
u = 4.*pi./3
diff = sin(u)./cos(u) - tan(u)
u = 5.*pi./3
diff = sin(u)./cos(u) - tan(u)
u = 2.*pi
diff = sin(u)./cos(u) - tan(u)

