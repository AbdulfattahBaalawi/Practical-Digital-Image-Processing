clear
clc
% 5. I like my shower to remain hot for hours at 100�F, but am too cheap
% to buy one of those on-demand hot water systems. I don�t care how
% slowly the water runs. The water supply is at 50�F, and the water
% heater is rated at 50,000 BTU/hour. Write a script to compute the
% maximum flow rate of my shower (in cubic feet per minute) that
% keeps the water temperature above 100�F.
%
% given a BTU is the energy necessary to raise a pound of water by 1�F
% and a cubic ft of water weighs 62.4 pounds
% If I am raising the water 50�F, 50,000 BTU per hour will heat 1,000 lb
% of water in an hour
weight = 1000  % lb per hour
volume = weight / 62.5  % cu ft / hour
flow = volume / 60  % cu ft / min