clear
clc
% 3. If an ice cream cone is 6 inches tall, and its rim has a diameter of 2
% inches, write a script to determine the weight of the ice cream that
% can fit in the cone, assuming that the ice cream above the cone is a
% perfect hemisphere. You may neglect the thickness of the cone
% material. Assume that a gallon of ice cream weighs 8 lb and
% occupies 7.5 cubic feet.
%
% the volume of a cone is 1/3 pi r^2h
% the volume of a hemisphere is 1/2 pi r^r
%
% given:
r = 1 % inches
h = 6 % inches
volume = pi .* r.^2 .* h ./ 3 + pi .* r.^2 ./ 2  % cu in
vol_cu_ft = volume ./ 12.^3
gallons = vol_cu_ft ./ 7.5
weight = gallons * 8  % lb
weight_oz = weight .* 16