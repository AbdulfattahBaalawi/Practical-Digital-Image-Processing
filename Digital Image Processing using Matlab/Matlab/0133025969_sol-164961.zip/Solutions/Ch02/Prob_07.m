clear
clc
% 7. You want to buy a $300,000 home with 20% down payment. The
% current compound interest rate is 4.5%.
% a. Write a script to determine:
% � the monthly payments for a 30-year loan,
% � the equivalent simple interest rate,
% � the total interest paid over the life of the loan.
% b. Now, repeat the computation for a 15-year loan at 5%. Is this a
% better deal?
%
%  Formula:
%   payment = r * PV / (1 - (1+r)^(-n))
%      PV is the loan principal
%      r is the rate per period
%      n is the number of months
cost = 300000 % $
downpayment = cost .* 0.2
PV = cost - downpayment
interest_rate = 4.5 % %
n = 360
r = interest_rate ./ (12 * 100)
payment = r .* PV ./ (1 - (1+r).^(-n))
total_interest = payment .* n - PV
simple_interest = 100 .* total_interest ./ (PV * 30) 
interest_rate = 5 % %
n = 180
r = interest_rate ./ (12 * 100)
payment = r .* PV ./ (1 - (1+r).^(-n))
total_interest = payment .* n - PV
simple_interest = 100 .* total_interest ./ (PV * 15) 


