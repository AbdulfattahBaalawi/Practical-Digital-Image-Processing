clear
clc
% 2. In the bottom of the ninth inning, the bases are loaded and the
% Braves are down by three runs. Chipper Jones steps to the plate.
% Twice he swings and misses. The crowd heads for the exits. The
% next pitch is a fast ball down the middle. He swings and makes
% perfect contact with the ball, sending it up at a 45-degree angle
% toward the fence 400 ft away.
% a. Write a script to determine how fast he must hit the ball to land
% at the base of the fence, neglecting the air resistance.
% b. Perform a brief experiment to determine whether there was a better
% angle at which to hit the ball so that it could clear a 12 ft fence.

% the formulae required are:
%  vertically,
%        s = ut + 1/2 a t^2
%     s, the distance traveled = 0
%     u, the initial velocity is V sin(th)
%     a, the acceleration, is -g
%     t, the flight time is unknown
%  horizontally, 
%        s = ut
%     s is the distance traveled
%     u is V cos(th)
%     t is provided by the vertical equation
%
% given data:
th = 45 .* pi ./ 180
dist = 400 % ft
g = 32.2 % ft/sec^2
% transforming the vertical equation:
%    u - 1/2 gt = 0
%  so t = 2u/g = 2Vsin(th)/g
% so the horizontal equation becomes:
%    dist = Vcos(th)*t = Vcos(th)*2Vsin(th)/g 
%    dist = 2V^2sin(th)cos(th)/g
% so V^2 = dist * g / sin(2th)
V = sqrt(dist * g / sin(2*th))
% Considering this equation, when th = 45, sin(2th) is 1, the most it can
% ever be, so this velocity is the least it can be when th is 45 deg.

