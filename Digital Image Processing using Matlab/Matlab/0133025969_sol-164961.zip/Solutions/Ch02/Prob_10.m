clear
clc
% 10. You can calculate the aerodynamic drag on an object by the
% formula:
% Drag = 1/2 r V^2 CdS
% The air density, r, is 1.3 kg/m^3 and the value of the drag area, CdS,
% is a measure of the resistance of the object as it moves through the
% air. An object falling through air reaches terminal velocity when the
% aerodynamic drag equals the object�s weight.
% A sky diver weighing 80 kg has a CdS value of 0.7 when horizontal
% with arms and legs extended, and 0.15 when head down with
% arms and legs in line. One diver jumps from a plane at an
% altitude of 5,000 m in the horizontal position. After 20 sec,
% another diver jumps. Write a script to determine how much
% time the second diver must spend head down in order to catch
% up to the first diver. Also compute the height above the ground
% where they first meet. For simplicity, you may assume that the
% sky divers immediately reach their terminal velocity when
% jumping.

% analysis
%  terminal vel ^2 = mass * acc * 2 / (r * CdS)
%  units are kg * (m / sec^2) / ((kg/m^3) * m^2)
%            = m^2 / sec^2
%  once we have each velocity,
%  first travels distance dh in t / tv1
%  second travels the same distance in (t - 20) /  tv2
% meeting time is found by equating these two:
%      t*tv1 = (t-20)*tv2
%      t = 20*tv2/(tv2-tv1)
%  distance fallen = t * tv1

% given
r = 1.3 % kg/m^3
CdS_flat = 0.7  % m^2
CdS_tuck = 0.15 % m^2
h = 5000 % m
dt = 20 % sec
mass = 80 % kg
g = 9.81 % m / sec^2
terminal_vel_1 = sqrt(mass .* g .* 2 ./ (r .* CdS_flat)) 
terminal_vel_2 = sqrt(mass .* g .* 2 ./ (r .* CdS_tuck)) 
time = dt .* terminal_vel_2 ./ (terminal_vel_2 - terminal_vel_1)
drop = time * terminal_vel_1
altitude = h - drop
% 

