clear
clc
close all
% 11. You are given a circle with radius 5 centered at x = 1, y = 2.
% You want to calculate the intersection of some lines with that
% circle. Write a script to find the x and y coordinates of both
% points of intersection. You should test this code at least with
% these lines:
% y = 2 x - 1
% y = -2 x - 10
% y = x + 5.9054
%
% equations
%   circle :   (x-xc)^2 + (y-yc)^2 = r^2
%     line :    y = m*x + c
%
%  solve for x and y:
%      (x-xc)^2 + (m*x + c - yc)^2 - r^2 = 0
%  quadratic of the form Ax^2 + Bx + C = 0
%  where A = 1 + m^2
%        B = -2xc + 2m(c - yc)
%        C = xc^2 + (c - yc)^2 - r^2
%   roots are x = (-B +/- sqrt(B^2 - 4AC)) / (2A)
xc = 1
yc = 2
r = 5
th = linspace(0, 2*pi);
plot(r*cos(th)+1, r*sin(th)+2)
axis equal
hold on
grid on
m = 1
c = 5.9054
A = 1+m.^2, B = 2.*(m.*c - xc - m.*yc), C = xc.^2 + (c-yc).^2 - r.^2
disc = sqrt(B.^2 - 4.*A.*C);
x1 = (-B + disc) ./ (2.*A), y1 = m*x1 + c
x2 = (-B - disc) ./ (2.*A), y2 = m*x2 + c
plot([x1 x2],[y1, y2], 'r+')
m = 2
c = -1
A = 1+m.^2, B = 2.*(m.*c - xc - m.*yc), C = xc.^2 + (c-yc).^2 - r.^2
disc = sqrt(B.^2 - 4.*A.*C);
x1 = (-B + disc) ./ (2.*A), y1 = m*x1 + c
x2 = (-B - disc) ./ (2.*A), y2 = m*x2 + c
plot([x1 x2],[y1, y2], 'g+')
