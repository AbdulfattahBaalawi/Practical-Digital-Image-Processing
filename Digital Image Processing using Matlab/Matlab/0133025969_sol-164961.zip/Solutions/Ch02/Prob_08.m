clear
clc
% 8. The distance from my house to my office is 1.5 miles. Every
% morning, I have to decide whether to take the bus that averages
% (once it arrives) 25 mph, or to walk. I can walk at 4 mph. Write
% a script to determine how frequently the buses should run to
% give them a 50% chance of getting me to the office faster than
% walking.
%
% analysis: 
%  1. compute the time it takes to walk to work
%  2. compute the time it takes on the bus
%  3. difference is the tolerable wait time (twt)
%  4. frequency is 1 / 2*twt
%
% given
distance  = 1.5   % miles
walk_speed = 4 % mph
bus_speed = 25 % mph
walk_time = distance / walk_speed
bus_time = distance / bus_speed
delay = walk_time - bus_time
buses_per_hour = 1 /  (2 .* delay)