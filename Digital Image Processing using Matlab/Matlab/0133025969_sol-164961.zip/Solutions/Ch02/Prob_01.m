clear
clc
% 1. You are given two sides of a triangle, a = 4.5 and b = 6. The angle
% between them is 35 degrees. Write a script to find the length of the
% third side and the area of the triangle.
%
%  The formula for the third side of a triangle is:
%            c^2 = a^2 + b^2 - 2ab cos(th)
%  where th is the angle between the sides a abd b
%  The formula for the area of a triangle is:
%            area = 1/2 ab sin th
%  Give data:
a = 4.5
b = 6
th = 35 * pi / 180
% Compute the third side
c = sqrt(a.^2 + b.^2 - 2 .* a .* b .* cos(th))
% Compute the area:
area = 0.5 .* a .* b .* sin(th)

