clear
clc
% 6. It takes an average of 45 horsepower to run an electric car at an
% average speed of 35 mph. Write a script to compute the electrical
% storage capacity of the battery system that would make this car
% practical for a 25-mile commute, recharging the batteries only at
% home at night when the electricity is cheap. How many D cell
% alkaline batteries would be needed for this?

% relevant information:
%  D cel capacity is approx 15000 mAh at 1.5 volts
%  one horsepower is 746 watts 
%  one watt is one joule per second
%  a joule is one amp in a one ohm resistor for one sec
%
% given data:
hp = 45   % horsepower
speed = 35 % miles per hour
dist = 50 % miles
running_time = dist/speed % hours
running_time_sec = running_time * 3600 % sec
power = hp * 746  % watts = joule / sec
energy = power * running_time_sec  % joules
recharge = energy / 3600000 % kwh
D_Cell_energy = 15 * 1.5 % watt_hours
D_Cells = ceil(1000 * D_Cell_energy / recharge)