clear
clc
% 9. A glass has the shape of a truncated cone of height 5 inches. Its top
% diameter is 3.5 inches, and its base diameter is 2 inches. If water is
% poured into the glass at 2 gallons per minute, write a script to
% calculate how long it takes to fill the glass to the brim. One gallon is
% 7.5 cubic feet.
%
% formula:
%    cone volume = 1/3 pi r^2 h
%    since the cone sides are straight, there is a linear relationship
%    between radius and height
%    taper = top_rad - bottom_rad /  ht
%    overall height of cone = taper * top_rad
%    missing_cone_height = taper * bottom_rad

% given:
top_rad = 3.5 ./ 2 % inches
bot_rad = 2 ./ 2 % inches
h = 5 % inches
rate = 2 % galls / min
gall_per_cu_ft = 7.5
% computations
taper = (top_rad - bot_rad) / h
h1 = top_rad .* taper
h2 = bot_rad * taper
v1 = pi .* top_rad.^2 .* h1 ./ 3
v2 = pi .* bot_rad.^2 .* h2 ./ 3
volume = v1 - v2 % cu in
vol_cu_ft = volume ./ 12.^3 % cu ft
vol_galls = vol_cu_ft * gall_per_cu_ft % galls
time = vol_galls / rate  % min
time_sec = time .* 60
