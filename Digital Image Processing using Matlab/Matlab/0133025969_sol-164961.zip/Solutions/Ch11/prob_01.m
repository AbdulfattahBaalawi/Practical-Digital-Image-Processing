clear
clc
close all
% 1. Write a script that creates six sub-plots in two columns each with 
%    three rows. Each plot should have an appropriate title and labels  
%    on the x and y axes. The plot in the top left sub-plot should be  
%    y = cos(?) for values of ? from -2? to 2?. Subsequent plots going  
%    across the rows before going down the columns should be of  
%    y = cos(2?), y = cos(3?), etc., to y = cos(6?) over the same range  
%    of ?.
th = linspace(-2*pi, 2*pi);
for spl = 1:6
    subplot(3,2,spl)
    plot(th, cos(spl*th))
    title(sprintf('plot of cos(%d*th)', spl))
    xlabel('theta')
    ylabel(sprintf('cos(%d*th)', spl))
end

