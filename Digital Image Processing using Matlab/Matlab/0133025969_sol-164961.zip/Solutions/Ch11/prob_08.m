function test
clc
close all
% 8. Write a function named plotRotation that takes in two vectors, x and z, 
%    and a vector th. Your function should plot three plots in the same figure 
%    by using the subplot command. The figure should have 1*3 plots. The plots
%    should be as follows:
% a. z vs. x, titled 'z vs. x'. Note that you will have to use plot3() to 
%    correctly plot this in the xz plane rather than the xy plane a plot() 
%    would do. Also, you should use view(0, 0) to make the plot produced by 
%    plot3() show up as 2D.
% b. z vs. x rotated around the x axis using mesh() with flat shading and a 
%    square axis, titled 'z vs. x about x using mesh'.
% c. z vs. x rotated around the z axis using surf() with interp shading and 
%    a square axis, titled 'z vs. x about z using surf'.
% For plots b and c, the input vector th should be used for your independent 
%    vector theta which is used to convert from polar to Cartesian coordinates. 
%    Don't forget to title and label each of the three plots
    th = linspace(0, 2*pi);
    x = 5 + 2*cos(th);
    z = 2*sin(th);
    plotRotation(x, z, th)
end

function plotRotation(u, v, th)
    subplot(1,3,1)
    plot3(u, zeros(1,length(u)), v)
    view(0,0)
    axis equal
    axis([0 7 0 1 -2 2])
    title('v vs. u')
    [uu tth] = meshgrid(u, th);
    vv = meshgrid(v, th);
    for pl = 2:3
        subplot(1,3,pl)
        if pl == 2
            rr = vv;
            xx = uu;
            zz = rr .* sin(tth);
        else
            rr = uu;
            zz = vv;
            xx = rr .* sin(tth);
        end
        yy = rr .* cos(tth);
        if pl == 2
            mesh(xx, yy, zz)
            colormap copper
            shading flat
            axis square
            title('v vs. u about x using mesh')
        else
            surf(xx, yy, zz)
            colormap copper
            shading interp
            axis equal
            title('v vs. u about z using surf')
        end
        axis off
        lightangle(45, 45)
    end
end