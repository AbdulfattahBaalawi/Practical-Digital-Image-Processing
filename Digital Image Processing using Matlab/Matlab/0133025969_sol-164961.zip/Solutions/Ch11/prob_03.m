function  test
clc
close all
% 3. Write a function called sineGraph that graphs a sine function four 
%    times between the interval [start,stop] on the same graph. The start  
%    and stop values should be parameters of the function. The number of  
%    points per interval will vary. More specifically:
% � The first time you graph the sine function, you should have two evenly 
%    spaced points, start and stop
% � The next plot should have 4 evenly spaced points�start, stop, and two  
%    points between them
% � The third should have 8 evenly spaced points and the fourth 256 points.
% � Make sure to add a legend and a title�'Multiple graphs on one plot' 
%    �and to label the axes. Make sure each line has a different color.
% � The function should return the x and y values for the 256 point set.
% Test your function with the following intervals  
%    [0,?/2], [0,2?], [0,4?], [0,16?]
    sineGraph(0,pi/2)
    figure
    sineGraph(0,2*pi)
    figure
    sineGraph(0,4*pi)
    figure
    sineGraph(0,16*pi)
end

function sineGraph(start, stop)
    plot([start stop], sin([start stop]))
    hold on
    th = linspace(start, stop, 4);
    plot(th, sin(th),'r')
    th = linspace(start, stop, 8);
    plot(th, sin(th),'g')
    th = linspace(start, stop, 256);
    plot(th, sin(th),'k')
    legend({'2 points','4 points','8 points','256 points'})
end
