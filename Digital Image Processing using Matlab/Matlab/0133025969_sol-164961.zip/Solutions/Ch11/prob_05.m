clear
clc
close all
% 5. Georgia Tech wants to tear down the Campanile and build a new one that 
%    is ridiculously tall. However, before they build it, they need you to  
%    model it. Using the equation z = 1/(x^2 + y^2) as the model, write a  
%    script that will plot the Campanile. Your domain should be  
%    -.75 <= x <=.75 and -.75 <= y <= .75 using an increment of .05 for each  
%    range. Set your axes such that all of the x, y domain is seen and z  
%    runs from 0 to 300. Use surf(...) to plot your image.
range = -0.75:0.005:0.75;
[xx yy] = meshgrid(range, range);
zz = 1 ./ (xx.^2 + yy .^2);
surf(xx, yy, zz)
axis([-0.75 0.75 -0.75 0.75 0 300])
axis off
colormap summer
shading interp
lightangle(45, 45)

