clear
clc
close all
% 2. Your task is to create a script called thisPlot. This script should 
%    do the following:
% a. Ask the user to enter in a positive number, N, greater than 5.
% b. Calculate the factorial for each number from 1 to N. Each of these  
%    values should be stored into a vector.
% c. Display a graph titled 'Logarithmic Growth', where the logarithms  
%    for each of the factorials are displayed.
% d. Add to the graph a continuous linear line that follows the equation  
%    y = x with x values from 1 to N.
% e. Since the numbers will have different magnitudes, use plotyy to plot  
%    the linear values on the right hand axis.
N = 19
v = factorial(1:N)
title('Logarithmic Growth')
plotyy(1:N, log(v), 1:N, 1:N)

    

