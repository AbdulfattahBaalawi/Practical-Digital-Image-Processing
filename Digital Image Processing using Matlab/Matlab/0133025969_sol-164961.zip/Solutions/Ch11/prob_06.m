clear
clc
close all
% 6. You are provided the file 'data.xls', which contains two columns of ****  
%    numbers. Each column contains the same number of elements. The first  
%    row contains the titles of the x and y values respectively. Create a  
%    script called spreadSheetPlot that plots the data in this file. The  
%    first column represents your x values and the second column is your  
%    y values. Read the numbers from the file and make a plot of the  
%    x vs. y values. Title your plot 'spreadSheetPlot' and use the first  
%    row data to label the x and y axes. 
[nums txt] = xlsread('data.xls');
plot(nums(:,1)', nums(:,2)')
title('spreadSheetPlot')
xlabel(txt{1,1})
ylabel(txt{1,2})
