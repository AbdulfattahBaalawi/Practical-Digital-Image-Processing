function test
    clc
% 7. In terms of atomic physics, every electron has four numbers associated 
%    with it, called the quantum numbers. These are 'principal' (energy), 
%    'azimuthal' (angular momentum), 'magnetic' (orientation of angular 
%    momentum) and 'spin' (particle spin) quantum numbers. Wolfgang Pauli 
%    hypothesized (correctly) that no two electrons in an atom can have the 
%    same set of four quantum numbers, i.e., if the Principal, Azimuthal, 
%    and Magnetic numbers are the same for two electrons, then it is 
%    necessary for the electrons to have different Spin numbers.
%    You need to write a function called spinSwitch that takes in two 
%    structures and returns both structures. Each structure represents an 
%    electron in a hydrogen atom and has the following fields:
%                principal (this is always > 0)
%                azimuthal (a number)
%                magnetic (A number)
%                spin (a string with value �up� or �down�)
%    Your function will compare the values in the two structures and check 
%    if they all have the same values for the four fields. If true, you 
%    are required to switch the spin of the second structure. You also 
%    have to add a field called 'energy' to both structures. The value 
%    stored in this field must be (-2.18*(10^18))/(n^2), where n is the
%    value of the principal quantum number for that electron. You have to 
%    return both the structures with the energy field added to both, 
%    so that the one with the higher energy is first. If the energies are 
%    equal, return the one with the 'up' spin first. If both have the 
%    same spin and the same energy, the order does not matter.
    el = struct('principal', {1 1 3}, ...
                'azimuthal', {2 2 4}, ...
                'magnetic', 3, ...
                'spin',{'up','up','down'});
    [a1 a2] = spinSwitch(el(1), el(2))
    [a3 a4] = spinSwitch(el(2), el(3))
end

function [a b] = spinSwitch(a, b)
    same = a.principal == b.principal ...
        && a.azimuthal == b.azimuthal ...
        && a.magnetic == b.magnetic ...
        && strcmp(a.spin , b.spin);
    a.energy = (-2.18*(10^18))/(a.principal^2);
    b.energy = (-2.18*(10^18))/(b.principal^2);
    if same
        if strcmp(b.spin, 'up') b.spin = 'down'; else b.spin = 'up'; end
    end
    if   a.energy < b.energy ...
     || (a.principal == b.principal && strcmp(a.spin, 'down'))
        t = a;
        a = b;
        b = t;
    end
end
 