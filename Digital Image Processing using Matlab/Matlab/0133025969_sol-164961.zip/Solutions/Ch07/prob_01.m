function test
    clc
% 1. Write a function named cellParse that takes in a cell array with each 
%    element being either a string (character array), or a vector  
%    (containing numbers), or a boolean value (logical array of length 1).
%    Your function should return the following:
%    � nStr : the number of strings
%    � nVec: the number of vectors
%    � nBool: the number of boolean values
%    � cString: a cell array of all the strings in alphabetical order
%    � vecLength: the average length of all the vectors
%    � allTrue: true if all the boolean values are true and false otherwise
% For example,
[a b c d e f] = cellParse( { [1 2 3], true, 'hi there!', 42, false, 'abc'} )
% should return a = 2, b = 2, c = 2, d = {'abc','hi there!'}, e = 2, and f = false.
end

function [nStr nVec nBool cString vecLength allTrue] = cellParse(ca)
    nStr = 0;
    nVec = 0;
    nBool = 0;
    cString = {};
    vecLength = 0;
    vl = 0;
    allTrue = true;
    for ndx = 1:length(ca)
        item = ca{ndx};
        switch class(item)
            case 'char'
                nStr = nStr + 1;
                cString = [cString ca(ndx)];
            case 'double'
                nVec = nVec + 1;
                vl = vl + length(item);
            case 'logical'
                nBool = nBool + 1;
                allTrue = allTrue & item;
        end
    end
    if nVec > 0, vecLength = vl ./ nVec;end
    cString = sort(cString);
end