function test
    clc
% 4. This problem deals with structures that represent dates.
%   a. First, write a MATLAB function called createDate that will take in 
%      three numeric parameters. The first parameter represents the month,  
%      the second represents the day, and the third the year.  
%      The function should return a structure with the following fields:
%        Day: a number
%        Month: a 3 character string containing the first three characters  
%               of the month name
%        Year: a number containing the year.
%      For example, 
it = createDate(3,30,2008) % should return a structure  
%      containing:
%               Day: 30
%             Month: Mar
%              Year: 2008
%   b. Write a function called printDate that displays a date in the form 
%      Mar 30, 2007
printDate(it)
%   c. Write a function inBetween that will take in three date structures.  
%      The function should return true if the second date is between the  
%      first and third dates, otherwise the function should return false.
inBetween(it, createDate(2,30,2008), createDate(4,30,2008))
inBetween(createDate(2,30,2008), it, createDate(4,30,2008))
inBetween(createDate(4,30,2008), it, createDate(2,30,2008))

%   d. Write a function called isSorted that takes in a single parameter,  
%      an array of date structures. This function should return true if all  
%      the dates in the array are in a chronological order (regardless of
%      whether they are in ascending or descending order), otherwise the  
%      function should return false.
%   e. Write a test script that creates an array of date structures, prints  
%      out each date, and then states whether or not the dates are in order.
% Hints:
% � It might help to add a field to the date structure.  ****
% � The third date does not have to be chronologically later than the first  
%      date.
    for it = 1:5
        day = 1+floor(rand(1,1)*30);
        mo = 1+floor(rand(1,1)*12);
        year = 2000+floor(rand(1,1)*13);
        da(it) = createDate(mo, day, year);
        fprintf('%s\n', printDate(da(it)))      
    end
    if isSorted(da), nt = '';
    else nt = ' not'; end
    fprintf('these dates are%s sorted\n', nt);
end

function res = isSorted(da) 
    res = true;
    ix = 3;
    while res && ix <= length(da)
        jx = 2;
        while res && jx < ix
            if ~inBetween(da(1), da(jx), da(ix))
                res = false;
            end
            jx = jx + 1;
        end
        ix = ix + 1;
    end
end


function str = createDate(mo, day, year)
    months = {'Jan','Feb','Mar','Apr','May','Jun', ...
              'Jul','Aug','Sep','Oct','Nov','Dec'};
    str.Day = day;
    str.Month = months{mo};
    str.Year = year;
    str.Value = (year*12 + mo)*31 + day;
end

function res = printDate(dt)
    res = sprintf('%s %d, %d', dt.Month, dt.Day, dt.Year);
end

function res = inBetween(d1, d2, d3)
    if d1.Value < d3.Value
        res = d2.Value > d1.Value & d2.Value < d3.Value;
    else
        res = d2.Value < d1.Value & d2.Value > d3.Value;
    end
    if res, nt = '';
    else nt = ' not'; end
    fprintf('[%s] is %s between [%s] and [%s]\n', printDate(d2), ...
        nt, printDate(d1), printDate(d3))
end