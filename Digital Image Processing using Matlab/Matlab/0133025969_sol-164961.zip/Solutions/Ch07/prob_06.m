function test
    clc
% 6. The MATLAB language has the built-in ability to perform mathematical 
%    operations on complex numbers. However, there are times when it is  
%    useful to treat complex numbers as a structure. Write a set of  
%    functions with the following capability and a script to verify that  
%    they work correctly:
%            cmplx = makeComplex(real, imag)
%            res = cmplxAdd( cmpxa, cmpxb )
%            res = cmplxMult( cmpxa, cmpxb )
    c1 = makeComplex(2, 3);
    c2 = makeComplex(1, -3);
    c3 = cmplxAdd(c1, c2);
    fprintf('%s + %s = %s\n', ...
        cmplxShow(c1), cmplxShow(c2), cmplxShow(c3))
    c4 = cmplxMult(c1, c2);
    fprintf('%s * %s = %s\n', ...
        cmplxShow(c1), cmplxShow(c2), cmplxShow(c4))
    c5 = makeComplex(2,0);
    c6 = cmplxMult(c1, c5);
    fprintf('%s * %s = %s\n', ...
        cmplxShow(c1), cmplxShow(c5), cmplxShow(c6))
end

function c = makeComplex(r, im)
    c.real = r;
    c.imag = im;
end

function c = cmplxAdd(c1, c2)
    c.real = c1.real + c2.real;
    c.imag = c1.imag + c2.imag;
end

function c = cmplxMult( c1, c2)
    amp1 = sqrt(c1.real.^2 + c1.imag.^2);
    ang1 = atan2(c1.imag, c1.real);
    amp2 = sqrt(c2.real.^2 + c2.imag.^2);
    ang2 = atan2(c2.imag, c2.real);
    amp = amp1 .* amp2;
    ang = ang1 + ang2;
    c.real = amp .* cos(ang);
    c.imag = amp .* sin(ang);
end

function str = cmplxShow(c)
    str = sprintf('[%1.3g + %1.3gi]', c.real, c.imag);
end

