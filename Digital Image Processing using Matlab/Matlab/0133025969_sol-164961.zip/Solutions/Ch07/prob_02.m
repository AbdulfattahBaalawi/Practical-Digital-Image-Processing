function test
    clc
    global acmeClothes
% 2. It turns out that since you have become an expert on rating clothing 
%    (Chapter 4, Problem 5), Acme Clothing Company has hired you to rate  
%    their clothes. Clothes are now represented as structures instead of  
%    vectors with the fields (all of which are numbers between 0 and 5):
%           Condition, Color, Price, Matches, and Comfort
% Acme has a much simpler way of rating their clothes than you used before:
%       Rating = 5 * Condition + 3 * Color + 2 * Price + Matches + 9 * Comfort
%    You have a function called makeClothes.m that will create a  ****
%    structure array called acmeClothes that contains clothes structures. 
%    You are to write a function called rateClothes that will add a ****
%    Rating field and a Quality field to each of the structures in the 
%    acmeClothes array. The Rating  field in each structure should contain 
%    the rating of that particular article of clothing. 
%    The Quality field is a string that is  
%        'premium'   if the Rating is over 80,  
%        'good' over 60,  
%        'poor' over 20, and  
%        'liquidated' for anything else.
% Notes:
% a) You MUST use iteration to solve this problem.
% b) To make things easy, just place the line makeClothes at the top of  
%    your script so you're guaranteed to have the correct acmeClothes array  
%    to work with.
% c) The fields are case sensitive, so make sure you capitalize them.
    acmeClothes = makeClothes;
    rateClothes
    for ndx = 1:length(acmeClothes)
     acmeClothes(ndx)
    end
end

function res = makeClothes
    for fld = 1:5
        for item = 1:8
            ca{item} = floor(rand(1,1) * 6);
        end
        data(fld,:) = ca;
    end
    res = struct('Condition', data(1,:), ...
                 'Color', data(2,:), ...
                 'Price', data(3,:), ...
                 'Matches', data(4,:), ...
                 'Comfort', data(5,:));            
end

function rateClothes
    global acmeClothes
    for ndx = 1:length(acmeClothes)
        item = acmeClothes(ndx);
        item.Rating = 5 * item.Condition ...
               + 3 * item.Color  ...
               + 2 * item.Price  ...
               + item.Matches  ...
               + 9 * item.Comfort;
        if item.Rating > 80,     item.Quality = 'premium';
        elseif item.Rating > 60, item.Quality = 'good';
        elseif item.Rating > 20, item.Quality = 'poor';
        else                     item.Quality = 'liquidated';
        end
        nac(ndx) = item;  
    end
    acmeClothes = nac;
end