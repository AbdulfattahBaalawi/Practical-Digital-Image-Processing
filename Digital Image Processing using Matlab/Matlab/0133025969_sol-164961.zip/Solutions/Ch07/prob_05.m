function test
    clc
% 5. Your university has added a new award for students that were 
%    "almost there" last semester and just missed getting into the Dean's  
%    List. Write a function called almost that consumes an array of student  
%    structures, and produces an array of names of those that have a  
%    semester GPA between 2.9 and 2.99 (inclusive). The student structure  
%    has the following fields:
%         Name - string (eg.: 'George P. Burdell')
%         Semester_GPA - decimal number (eg.: 2.97)
%         Cumulative_GPA - decimal number (eg.: 3.01)
    students = struct('Name',{'Fred','Sally','Ann','Joe','George','Maggie'}, ...
                      'Semester_GPA', {1, 2.91, 4, 2.99, 3, 2.9}, ...
                      'Cumulative_GPA', 0);
    names = almost(students)
end

function names = almost(st)
    names = {};
    for student = st
        gpa = student.Semester_GPA;
        if gpa >= 2.9 && gpa <= 2.99
            names = [names student.Name];
        end
    end
end