function test
    clc
% 3. You have been hired by a used-car dealership to modify the price of 
%    cars that are up for sale. You will get the information about a car,  
%    and then change its price tag depending on a number of factors.
%    Write a function called usedCar that takes in a structure with the  
%    following fields:
%       Make: A string that represents the make of the car.  
%                  (e.g.: 'Toyota Corolla')
%       Year: A number that corresponds to the year of the car. (e.g.: 1997)
%       Cost: A number that holds the marked price of the car (e.g.: 7000)
%      Miles: The number of miles clocked.(e.g.: 85,000)
%  Accidents: The number of accidents the car has been in.(e.g.: 1)
%    Your function should return a structure with all the above fields,  
%    with *exactly* the same names. It should have the same make, year,  
%    accidents and miles. Here are the changes you must make:
%     1. Add 5,000 to the cost if the car has clocked less than 20,000 miles.
%     2. Subtract 5,000 if it has clocked more than 100,000 miles.
%     3. Reduce the price by 10,000 for every accident.
    revised = usedCar(struct('Make', 'Toyota Corolla', ...
                             'Year', 1997, ...
                             'Cost', 7000, ...
                             'Miles', 85000, ...
                             'Accidents', 2))
    revised = usedCar(struct('Make', 'Cadillac Escalade', ...
                             'Year', 2011, ...
                             'Cost', 75000, ...
                             'Miles', 15000, ...
                             'Accidents', 0))
end

function str = usedCar(str)
    if str.Miles < 20000, str.Cost = str.Cost + 5000;
    elseif str.Miles > 100000, str.Cost = str.Cost - 5000; end
    str.Cost = str.Cost - 10000 .* str.Accidents;
end