clear
clc
% 1. This is a set of simple matrix manipulations.
% a. Create a five by six matrix, A, that contains random numbers between 
%    0 and 10.
A = rand(5,6)*10
% b. Create a six by five matrix, B, that contains random numbers between 
%    0 and 10.
B = rand(6,5)*10
% c. Find the inverse of matrix A*B and store it in the variable, C.
C = inv(A*B)
% d. Without iteration, create a new matrix D that is the same as A except  
%    that all values less than 5 are replaced by zero.
D = A;
D(D<5) = 0
% e. Using iteration, create a new matrix F that is the same as A except 
%    that all values less than 5 are replaced by zero.
[rows cols] = size(A);
F = zeros(rows, cols);
for r = rows
    for c = cols
        if A(r,c) >= 5, F(r,c) = A(r,c); end
    end
end
% f. Create a new matrix G that is the matrix A with the columns reversed.  
%    For example:
% if A is [1 2 3; 3 2 5; 1 7 4], G should be
% [3 2 1; 5 2 3; 4 7 1]
G = A(:, end:-1:1)
% g. Find the minimum value amongst all the elements in A and store your  
%    answer in the variable H.
H = max(max(A))
