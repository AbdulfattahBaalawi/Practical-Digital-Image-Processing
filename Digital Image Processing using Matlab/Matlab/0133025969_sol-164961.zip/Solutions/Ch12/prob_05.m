function test
    clc
    close all
% 5. Write a function named solveSystem that has three inputs: two vectors  
%    consisting of the coefficients [a b c] of two line equations of the  
%    form ax + by = c and a vector of x values
% a. The function should output a vector giving the x and y values of the  
%    point of intersection between the two lines. If the lines are parallel,  
%    return the empty vector.
% b. Your function should also plot the two lines using the inputted vector  
%    of x values as x. In addition, on the same graph, plot the intersection  
%    point of the two lines. Make the first line blue, the second line 
%    red, and the intersection point a magenta diamond. Make sure that you  
%    label your plot appropriately
    solveSystem(rand(1,3)*2-1, rand(1,3)*2-1, [-5 5])
end

function V = solveSystem(v1, v2, x)
    % to solve for the intersection of lines a1x + b1y + c1 = 0
    %  [a1 b1  * x = -c1
    %   a2 b2]   y   -c2
    
    A = [v1(1) v1(2)
         v2(1) v2(2)];
    B = [-v1(3)
         -v2(3)];
    V = (A \ B)';
    % to plot either line:
    % y = -c/b - a x/b
    y1 = -v1(3)/v1(2) - v1(1) * x ./ v1(2);
    plot(x, y1)
    hold on
    y2 = -v2(3)/v2(2) - v2(1) * x ./ v2(2);
    plot(x, y2, 'r')
    plot(V(1), V(2), 'md')
    xlabel('X')
    ylabel('Y')
    text(V(1)+.2,V(2)+.2, 'intersection')
    title('intersecting two lines')
end