function test
clc
% 4. Write a function called rotateLine that takes in two vectors, x and y,  
%    of the same length that represent a set or ordered pairs that could be  
%    used to plot a line. Your function should also take in a third parameter,  
%    theta, representing an angle in degrees. Your function should return  
%    xprime and yprime where xprime and yprime represent the line that is  
%    x and y rotated about the origin by the angle theta. For example:
x = [ 7 7 11 11 7];
y = [-5 -9 -9 -5 -5];
[xprime yprime] = rotateLine(x, y, 90) % returns xprime = [5 9 9 5 5]
%                                                yprime = [7 7 11 11 7]
end

function [xp yp] = rotateLine(x, y, th)
    A = [cosd(th), -sind(th)
         sind(th),  cosd(th)];
    V1(1,:) = x;
    V1(2,:) = y;
    V2 = A*V1;
    xp = V2(1,:);
    yp = V2(2,:);
end

