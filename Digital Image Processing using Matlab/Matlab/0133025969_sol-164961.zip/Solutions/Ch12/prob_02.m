clear
clc
% 2. Imagine that world leaders have decided to come up with a single  
%    currency for the world. This new currency, called the Eullar, is  
%    defined by the following:
%           Seven dollars and three Euros make seventy-one Eullars.
%           One dollar and two Euros make twenty Eullars.
%    You are a reputed economist and your job is to find out the value of a  
%    dollar in terms of Eullars.
 
A = [7 3
     1 2]
B = [71
     20]
V = A\B
B1 = A*V
fprintf('one dollar is %f Eullars\n', V(1))
 
