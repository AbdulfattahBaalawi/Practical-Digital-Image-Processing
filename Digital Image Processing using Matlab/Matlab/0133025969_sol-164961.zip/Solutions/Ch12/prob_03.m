clear
clc
% 3. As an enthusiastic and motivated student, you decided to go out and buy  
%    plenty of pens for all your classes this semester. This spending spree  
%    unfortunately occurred before you realized your engineering classes  
%    seldom required the use of �ink�. So now, you�re left with four different  
%    types of pens and no receipt�you only remember the total amount you  
%    spent, and not the price of each type of pen. You decide to get together  
%    with three of your friends who coincidentally did the same thing as you,  
%    buying the same four types of pens and knowing only the total amount.  
%    Write a script to find the prices of each type of pen.
% Hint: In order to find the price of each individual pen, you could create  
%    a matrix called �pens�, where each column represents a different type  
%    of pen and each row represents a different person and a column vector  
%    totals that contains the amount of money each of you spent on the pens.
pens = ceil(rand(4,4)*4+2)
amount = rand(4,1)*5
price = pens\amount
