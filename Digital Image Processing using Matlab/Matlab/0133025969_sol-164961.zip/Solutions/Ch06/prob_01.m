function test
    clc
% 1. Solve the following introductory problems on strings.
% a. Write a function dayName that consumes a parameter, day, containing 
%    the numerical value of a day in the month of September 2008.  
%    Your function should return the name of that day as a string.  
%    For example:
    name = dayName( 8 ) % should return 'Monday'
    % b. You are now given a variable named days, a vector that contains the  
    %    numeric values of days in the month of September 2008.  
    %    Write a script that will convert each numeric value in the vector days  
    %    into a string named daysOfWeek with the day names separated by a comma  
    %    and a space. For example, if 
    days = [8, 9, 10]; % daysOfWeek should be �Monday, Tuesday, Wednesday�
    % Hint: You should probably be concatenating the day names and the delimiters.
    % Notice that there is no separator before the first day name or after the 
    % last one.
    res = '';
    for ndx = 1:length(days)
        res = [res dayName(days(ndx))];
        if ndx < length(days)
            res = [res ', '];
        end
    end
    res
end

function name = dayName(day)
    century = 6;
    year = 8;
    leapyear = floor(year/4);
    month = 5;
    it = day + month + year + leapyear + century;
    index = mod(it, 7);
    switch index
        case 0, name = 'Sunday';
        case 1, name = 'Monday';
        case 2, name = 'Tuesday';
        case 3, name = 'Wednesday';
        case 4, name = 'Thursday';
        case 5, name = 'Friday';
        case 6, name = 'Saturday'
    end
end

