function test
    clc
% 5. You have a big problem. In one of your CS courses, your professor 
%    decides that the only way you will pass the class is if you write a  
%    function to get him out of a mess. All the grades in his class have  
%    been accidentally stored into one long string of characters containing  
%    only the letters A, B, C, D, F, and Y.
% a. Your job is to write a function called CrazyGrade that will take in  
%    the string and flip the grades according to the following specifications:
        % A becomes F
        % B becomes D
        % C remains unchanged
        % D becomes B
        % F becomes A
        % Y becomes W
% Your function should take in a string and return an inverted string.  
%    You may assume that the string will only consist of valid letter grades.  
%    For example,
 CrazyGrade('BADDAD') % should return 'DFBBFB'
 CrazyGrade('BAYBAY') % should return 'DFWDFW'
% b. To make matters worse, he wants you to organize this modified grade  
%    set. Write a function called GradeDist to bunch together all the  
%    similar grades (put all the A�s next to each other, B�s next to each  
%    other, etc.) Then calculate and return the professor�s grade  
%    distribution. Your function should take in a string and return a  
%    string with all similar grades grouped together, along with an  
%    array containing percentage values from A�s all the way 
%    to F�s. For example, if there are  
%           15% A�s, 16% B�s, 33% C�s, 16% D�s, 16% F�s and 4% W�s,  
%    GradeDist should return [15 16 33 16 16 4].
 [str vec] = GradeDist('ABCDFWABCDFWABCDFABCDABCABA')
end

function res = CrazyGrade(str)
    res = str;
    res(str == 'A') = 'F';
    res(str == 'B') = 'D';
    res(str == 'D') = 'B';
    res(str == 'F') = 'A';
    res(str == 'Y') = 'W';
end

function [res vec] = GradeDist(str)
    res = sort(str);
    vec(1) = length(find(str == 'A'));
    vec(2) = length(find(str == 'B'));
    vec(3) = length(find(str == 'C'));
    vec(4) = length(find(str == 'D'));
    vec(5) = length(find(str == 'F'));
    vec(6) = length(find(str == 'W'));
end