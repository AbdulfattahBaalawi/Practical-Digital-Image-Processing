function test
    clc
% 4. The function rot(s, n) is a simple Caesar cipher encryption algorithm 
%    that replaces each English letter in places forward or backward along  
%    the alphabet in the strings. For example, the result of 
rot('Baz!',3) % is �Edc!�.  
%    An encrypted string can be deciphered by simply performing the inverse  
%    rotation on it, i.e., 
rot('Edc!',-3) %, which rotates each English letter in the strings three  
%    places to the left. Numbers, symbols, and non-letters are not
% transformed. Implement the following function:
%              function rotatedText=rot(text,n).  
%    To assist you as you solve this problem,  you could write several  
%    functions as local functions in the rot.m file:
%        isUppercaseLetter(letter),  
%        getUppercaseLetter(n),  
%        getLowercaseLetter(n), and  
%        getPosition(letter).  
%    You may also wish to use the built-in functions  
%    isletter (�), find (�), and mod (�).
rot(rot('>>abcxyzABCXYZ<<',6),-6)
end

function str = rot(str, n)
    lowers = isLowercaseLetter(str);
    them = str(lowers) - 'a' + n;
    them(them >= 26) = them(them >= 26) - 26;
    them(them < 0) = them(them < 0) + 26;
    str(lowers) = 'a' + them;
    uppers = isUppercaseLetter(str);
    them = str(uppers) - 'A' + n;
    them(them >= 26) = them(them >= 26) - 26;
    them(them < 0) = them(them < 0) + 26;
    str(uppers) = 'A' + them;
end

function res = isUppercaseLetter(letter)
    res = letter >= 'A' & letter <= 'Z';
end

function res = isLowercaseLetter(letter)
    res = letter >= 'a' & letter <= 'z';
end


