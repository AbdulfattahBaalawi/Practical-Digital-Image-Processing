function test
    clc
% 3. Write a function called DNAcomplement that consumes a set of letters 
%    as a character array that form a DNA sequence such as 'gattaca'.  
%    The function will produce the complement of the sequence so that  
%    a's become t's, g's become c's, and vice versa. The string 'gattaca'  
%    would therefore become 'ctaatgt'. You may assume that all the
% letters in the sequence will be lowercase and that they will all be  
%    either a,t,g, or c.
% Note: You may be tempted to use iteration for this problem, but you  
%    don't need it.
    res = DNAcomplement('gattaca')  % -> 'ctaatgt'
    res = DNAcomplement('aaccggtt') % -> 'ttggccaa'
end

function res = DNAcomplement(str)
    res(str == 'a') = 't';
    res(str == 't') = 'a';
    res(str == 'c') = 'g';
    res(str == 'g') = 'c';
end


