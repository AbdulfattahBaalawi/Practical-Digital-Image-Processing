function test
    clc
    close all
% 3. Write a function named plotSound that takes in the name of a sound 
%    file and produces a 1*2 figure with two plots. The first plot should 
%    be a plot of the sound in the time domain. The second plot should be 
%    a plot of the sound in the frequency domain. Your function should not 
%    return anything. Label the first plot 'Time Domain' and label its axes 
%    appropriately. Label second plot 'Frequency Domain' and label its axes 
%    appropriately.
%    The Time Domain plot should be an amplitude vs. time plot. For 
%    simplicity make sure your time vector starts at 0 (delta time) ******
%    and goes to n*dt (tmax) where n is the number of samples.
%    The Frequency Domain plot should be a power vs. frequency plot where 
%    power is the absolute value of the FFT of the amplitude values. For 
%    simplicity make sure your frequency vector starts at 0 ***** error
%    (delta frequency) and goes to n*df (2*fmax).
    plotSound('instr_piano.wav')
end


function plotSound(name)
    [note Fs] = wavread(name);
    N = length(note)
    tmax = N/Fs;
    dt = tmax/N;
    t = linspace(dt, tmax, N);
    subplot(2,1,1)
    plot(t, note);
    xlabel('time (sec)')
    ylabel('amplitude')
    title('Time Domain')
    fmx = Fs/4;
    df = fmx*4/Fs;
    f = linspace(0, fmx, N/4);  % ******* error in the instructions
    F = abs(fft(note));
    F = F(1:N/4);
    [~, where] = max(F);
    fprintf('frequency with max power is %f\n', f(where))
    subplot(2,1,2)
    plot(f, F)
    xlabel('frequency (hz)')
    ylabel('amplitude')
    title('Frequency Domain')
end

