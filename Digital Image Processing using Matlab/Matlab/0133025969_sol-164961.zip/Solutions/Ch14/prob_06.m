function test
    clc
    close all
% 6. Finally, you will use these tools to play your favorite song.
% a. Find the music for your favorite song and translate it into the 
%    symbology of Problem 14.5.
% b. Write a script that uses the playNote function to play your song on 
%    the piano.
% c. Modify playNote to use your synthetic instrument from Problem 14.3 
%    and save it as playSynthetic.
% d. Write a script that uses playSynthetic to play your song in futuristic 
%    style

global Fs
global newSound
global snd
global noteLength
global N
global start

part1 = {'G3' 0.75   % Oh         Whose
         'E3' 0.25   % o          broad
         'C3' 1      % say        stripes 
         'E3' 1      % can        and
         'G3' 1      % you        bright
         'C4' 2      % see        stars
         'E4' 0.75   % by         through
         'D4' 0.25   % the        the
         'C4' 1      % dawn's     per-
         'E3' 1      % ear-       il-
         'FS3' 1      % ly        ous
         'G3' 2      % light      fight
         'G3' 0.5    % what       o'er
         'G3' 0.5    % so         the
         'E4' 1.5    % proud-     ram-
         'D4' 0.5    % ly         parts
         'C4' 1      % we         we
         'B4' 2      % hail'd     watched
         'A4' 0.75   % at         were
         'B4' 0.25   % the        so
         'C4' 1      % twi-       gal-
         'C4' 1      % light's    lant-
         'G3' 1      % last       ly
         'E3' 1      % gleam-     stream-
         'C3' 1      % ing        ing
       };         

    part2 = { 
         'E4' 0.5   % and
         'E4' 0.5   % the
         'E4' 1     % rock-
         'F4' 1     % ets
         'G4' 1     % red
         'G4' 2     % glare
         'F4' 0.5   % the
         'E4' 0.5   % bombs
         'D4' 1     % burst-
         'E4' 1     % ing
         'F4' 1     % in
         'F4' 2     % air
         'F4' 1     % gave
         'E4' 1.5   % proof
         'D4' 0.5   % through
         'C4' 1     % the 
         'B4' 2     % night
         'A4' 0.75  % that
         'B4' 0.25  % our
         'C4' 1     % flag
         'E3' 1     % was 
         'FS3' 1    % still
         'G3' 2     % there
         'G3' 1     % Oh
         'C4' 1     % say
         'C4' 1     % does
         'C4' 0.5   % tha-
         'B4' 0.5   % at
         'A4' 1     % star
         'A4' 1     % span-
         'A4' 1     % gled
         'D4' 1     % ba-
         'F4' 0.5   % ne-
         'E4' 0.5   % er
         'D4' 0.5   % ye-
         'C4' 0.5   % -et
         'C4' 1     % wa-
         'B4' 1.75  % ave
         'G3' 0.5   % O'er
         'G3' 0.5   % the
         'C4' 1.5   % la-
         'D4' 0.5   % and
         'E4' 0.5   % of
         'F4' 0.5   % the
         'G4' 2.5   % free
         'C4' 0.5   % and
         'D4' 0.5   % the
         'E4' 1.5   % home
         'F4' 0.5   % of 
         'D4' 1     % the
         'C4' 6     % brave
         };
   
    [snd Fs] = wavread('instr_piano.wav');
    N = length(snd);
    for instr = 1:2
        start = 1;
        beat = 0.3;              % time consumed by one "quarter note"
        noteLength = beat * Fs;  % length on quarter note sound
        % calculate the maximum possible length of the resulting sound
%        overall = ((2*duration(part1) + duration(part2)) + N)/2;
        overall = duration(part2)/2 + N;
        % create new, empty sound because all the notes are added in
        newSound = zeros(overall, 1);
%        play(part1);
%        play(part1);
        play(part2);
        Y = fft(snd);
        f = linspace(0, Fs, N);
        plot(f(1:end/4),abs(Y(1:end/4)))
        sound(newSound, Fs)
        if instr == 1
            figure
            tmax = N/Fs;
            t = linspace(1, tmax, N);
            fundamental_freq = 261.5;  %  Middle C
            omega = 4 * pi * fundamental_freq;
            snd(:,:) = 0;
            snd = (cos(omega .* t)' + cos(3*omega .* t)' ...
                 + cos(2*omega .* t)'/2 + cos(4*omega .* t)'/2  )/3;
        end
    end
end

function it = duration(score)
    global Fs
    it = 0;
    for ndx = 1:length(score)
        it = it + score{ndx,2};
    end
    it = it * Fs;
end


function play(score)
    global newSound
    global noteLength
    global N
    global snd
    global start
    global Fs
    
    for step = 1:length(score)  % take each note from the score
       note = score{step, 1};   % find the note name (e.g. 'G4')
       pitch = getPitch(note);  % convert to a stretch factor
       duration = ceil(score{step, 2} * Fs/2);   % playing duration
       ndx = ceil(linspace(1, N, N/pitch));  % index vector
       if length(ndx) > duration  % crop to the note duration
           ndx = ndx(1:duration); % if there is enough data
       end
       % calculate where to insert this node into the output sound
       where = start:(start + length(ndx) - 1);  
       % add in the sound bite
       newSound(where) = newSound(where) + snd(ndx)/3;
       % mode down the output sound by the note duration
       start = start + duration;
    end
end


function pitch = getPitch(note)
% convert a note name like 'FS5' to the frequency multiplier from
% 'C3', middle C
    half = 2.^(1/12);
    switch note(1:end-1)
        case {'C' 'R'}   % R would be a rest - note of zero amplitude
            power = 0;
        case {'CS' 'DF'}
            power = 1;
        case 'D'
            power = 2;
        case {'DS' 'EF'}
            power = 3;        
        case 'E'
            power = 4;
        case 'F'
            power = 5;
        case {'FS' 'GF'}
            power = 6;
        case 'G'
            power = 7;
        case {'GS' 'AF'}
            power = 8;
        case 'A'
            power = -3;
        case {'AS' 'BF'}
            power = -2;
        case 'B'
            power = -1;
        otherwise
            error(['bad note value: ' note])
    end
    let = note(end) - '0';
    diff = let - 4;
    power = power + 12 * diff;
    pitch = half .^ power;
end
