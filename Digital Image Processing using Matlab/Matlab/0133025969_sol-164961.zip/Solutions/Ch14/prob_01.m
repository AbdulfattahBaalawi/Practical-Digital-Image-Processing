clear
clc
close all
% 1. These are fundamental exercises with sound files. You should not 
%    hard-code any of the answers for this problem, and you should not need  
%    iteration.
% a. Select and read a suitable .wav file and save the sound values and  
%    sampling frequency.
[note Fs] = wavread('instr_piano.wav');
sound(note, Fs)
N = length(note)
% b. Create a new sound that has double the frequency of the original  
%    sound and store your answer in the variable sound_Double.
sound_Double = note(1:2:end);
sound(sound_Double, Fs)
% c. Create a new sound that is the same as the original except that the  
%    pitch is raised by 5 half tones. Store your answer in the variable  
%    raised_pitch.
half5 = 2.^(5/12);
N5 = ceil(N ./ half5);
ndx = ceil(linspace(1, N, N5));
raised_pitch = note(ndx);
sound(raised_pitch, Fs)
% d. We need a figure showing two views each of these three sounds,  
%    created using subplot. In the left column, plot the original sound,   
%    sound_Double, and raised_pitch, labeling each plot accordingly. 
%    In the right column, plot the first quarter of the values of the  
%    power spectrum of each sound with the proper frequency values on the  
%    horizontal axis.
subplot(3,2,1)
tmx = length(note)/Fs;
t = linspace(0,tmx, N);
fmx = Fs/4;
f = linspace(0,fmx, N/4);
plot(t, note)
title('note')
subplot(3,2,2)
F = abs(fft(note));
plot(f, F(1:N/4))
title('note spectrum')

subplot(3,2,3)
N = length(sound_Double);
tmx = length(sound_Double)/Fs;
t = linspace(0,tmx, N);
fmx = Fs/4;
f = linspace(0,fmx, N/4);
plot(t, sound_Double)
title('sound Double')
subplot(3,2,4)
F = abs(fft(sound_Double));
plot(f, F(1:N/4))
title('sound Double spectrum')

subplot(3,2,5)
N = length(raised_pitch);
tmx = length(raised_pitch)/Fs;
t = linspace(0,tmx, N);
fmx = Fs/4;
f = linspace(0,fmx, N/4);
plot(t, raised_pitch)
title('raised pitch')
subplot(3,2,6)
F = abs(fft(raised_pitch));
plot(f, F(1:N/4))
title('raised pitch spectrum')

% e. Play each of the sounds in the following order: original sound,  
%    sound_Double, and raised_pitch each at the original sampling frequency.

