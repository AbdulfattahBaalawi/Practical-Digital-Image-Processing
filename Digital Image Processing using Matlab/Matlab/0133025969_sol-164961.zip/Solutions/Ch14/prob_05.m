function test
    clc
% 5. Write a function named playNote that takes in a string representing a 
%    note on the piano. Your function should return a vector representing  
%    the amplitude values of the note in addition to the correct sampling  
%    frequency to be used to play it back. You should do this by modifying  
%    the sound in the provided instr_piano.wav file which is Middle C  
%    played on the piano.  
%    Note that the returned sampling frequency should be the same as that  
%    instr_piano..wav.
%    Here is a list of all the possible note names representing notes that  
%    your function should work with and below that is the number of half  
%    steps above/below the middle C for that note:
%    cn cn# dn dn# en fn fn# gn gn# a(n+1) a(n+1)# b(n+1) c(n+1)
%   -12 -11 -10 -9 -8 -7 -6 -5 -4 -3 -2 -1 0
%    where c4 is the middle C, c5 is 1 octave above it and c3 is 1 octave  
%    below it. Similarly, f5 is 1 octave higher than f4, etc.  
%    For example, 
    global note
    global Fs
    [note Fs] = wavread('instr_piano.wav');
    notes = {'c4', 'd4','e4','f4','g4','a5','b5','c5'};
    for ndx = 1:length(notes)
        it = notes{ndx};
        [y1 fs] = playNote(it); % should return a vector such that sound(y1, fs)  
%    should sound like middle C
        sound(y1(1:fs/4), fs)
    end
end

function [y fs] = playNote(str)
    global note
    global Fs
    fs = Fs;
    half = 2.^(1/12);
    switch str(1:end-1)
        case {'c'}
            power = 0;
        case {'c#'}
            power = 1;
        case 'd'
            power = 2;
        case {'d#'}
            power = 3;        
        case 'e'
            power = 4;
        case 'f'
            power = 5;
        case {'f#'}
            power = 6;
        case 'g'
            power = 7;
        case {'g#'}
            power = 8;
        case 'a'
            power = -3;
        case {'a#'}
            power = -2;
        case 'b'
            power = -1;
        otherwise
            error(['bad note value: ' str])
    end
    let = str(end) - '0';
    diff = let - 4;
    power = power + 12 * diff;
    pitch = half .^ power;
    n = length(note);
    ndx = floor(linspace(1,n, n/pitch));
    y = note(ndx);
end
