function test
    clc
    close all
% 2. Write a function that will accept a string specifying a sound file 
%    and do the following:
% a. Play back the sound.
% b. Plot the sound in the time domain, titling and labeling your plot 
%    appropriately.
% c. Compute the frequency with the most energy in this file.
% Validate your answer by plotting the lower quarter of the frequencies 
%    of the Fourier transform of the sound. Don�t forget that the Fourier 
%    Transform is complex; you will need to reason with and plot the
%    absolute value of the spectrum.
% d. Test this function with suitable .wav files.
    sound_test('instr_piano.wav')
end


function sound_test(name)
    [note Fs] = wavread(name);
    sound(note, Fs)
    N = length(note)
    tmax = N/Fs;
    dt = tmax/N;
    t = linspace(dt, tmax, N);
    plot(t, note);
    xlabel('time (sec)')
    ylabel('amplitude')
    fmx = Fs/4;
    df = fmx*4/Fs;
    f = linspace(df, fmx, N/4);
    F = abs(fft(note));
    F = F(1:N/4);
    [~, where] = max(F);
    fprintf('frequency with max power is %f\n', f(where))
    figure
    plot(f, F)
end
