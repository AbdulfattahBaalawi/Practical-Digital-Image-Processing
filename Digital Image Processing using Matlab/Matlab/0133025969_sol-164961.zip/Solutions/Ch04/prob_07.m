clear
clc

% 7. Now that you�re comfortable with iteration, you�re going to have to 
%    solve an interesting problem. It seems that the Math department at  
%    a rival university has once again dropped the ball, and forgotten the  
%    value of pi.
%    You are to write a script which consumes a number that  **** error!
%    specifies the required accuracy and then and approximates the value  
%    of pi to that accuracy. You are going to use the following algorithm  
%    based on geometric probability.
%    Think about a quarter circle inside of a unit square (the quarter  
%    circle has area pi/4). You pick a random point inside the square.  
%    If it is in the quarter circle, you get a �hit� and if not, you get  
%    a �miss�. The approximate area of the quarter circle will be given by  
%    the number of hits divided by the number of points you chose.
%    Your script should repeat the process of counting hits and misses
%    until at least 10,000 tries have been made, and the successive  
%    estimates of pi are within the prescribed accuracy. It should produce  
%    the estimated value of pi.
%    Hint: you could use the function rand (�) in this problem
N = 10;
for power = 1:7
    hits = 0;
    misses = 0;
    for iter = 1:N
        pt = rand(1,2);
        dist = sum(pt.^2);
        if dist < 1
            hits = hits + 1;
        else
            misses = misses + 1;
        end
    end
    fprintf('estimate of pi is %5.4f\n', 4 .* hits ./ N)
    N = N .* 10;
end
