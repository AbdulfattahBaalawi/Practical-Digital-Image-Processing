clear
clc

% 2. You must use either for or while to solve the following problems.
% a. Iterate through a vector, A, using a for loop and create a new vector, 
%    B, containing logical values. The new vector should contain true for
%    positive values and false for all other values. For example, if 
A = [-300 2 5 -63 4 0 -46] 
% the result should be B = [false true true false true true false]
for ndx = 1:length(A)
    B(ndx) = A(ndx) >= 0
end
% b. Iterate through the vector, A, using a while loop and return a new 
% vector, B, containing true for positive values and false for all other values.
ndx = 1;
while ndx <= length(A)
    B(ndx) = A(ndx) >= 0
    ndx = ndx + 1;
end
% c. Iterate through a logical array, N, using a for loop and return a new 
% vector, M, containing the value 2 wherever an element of N is true and 
% the value -1 (not a logical value) wherever N is false. For example, if 
N = [true false false true true false true]
M = [];
for val = N
    if val
        M = [M 2]
    else
        M = [M -1]
    end
end
% the result should be M = [2 -1 -1 2 2 -1 2]

% d. Iterate through an array, Z, using a while loop. Replace every element 
% with the number 3 until you reach a number larger than 50. Leave the rest 
% unchanged. For example, if 
Z = [4 3 2 5 7 9 0 64 34 43] 
ndx = 1;
found = false
while ~found && ndx <= length(Z)
    found = Z(ndx) > 50
    if ~found
        Z(ndx) = 3;
    end
    ndx = ndx + 1;
end
Z
%, after running your
% script, Z = [3 3 3 3 3 3 3 3 34 43]