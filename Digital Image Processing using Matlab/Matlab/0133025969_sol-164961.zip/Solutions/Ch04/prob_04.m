clear
clc

% 4. You were just hired for a summer internship with one of the area's 
%  best software companies; however, on your first day of work you learn  
%  that for the next 3 months, the only job you will have is to convert  
%  binary (base 2) numbers into decimal numbers (base 10). You decide to  
%  write a script that will repetitively ask the user for a binary number  
%  and return its decimal equivalent until an illegal number (one  
%  containing digits other than 0 or 1) is entered. The number entered  
%  should contain only the digits 0 and 1. The rightmost digit has the value
%  2^0 and the digit N places to the left of that has the value 2^N.  
%  For example, entering 110101 returns 53 = 2^5 + 2^4 + 2^3 + 2^0
%  You must use iteration to solve this problem. Note: The input (�)  
%  function prompts the user for a value, parses the characters entered  
%  according to normal MATLAB rules and returns the result.
quit = false;
while ~quit
    str = input('binary: ','s');
    quit = ~all(str == '0' | str == '1');
    if ~quit
        str = str(end:-1:1);
        res = 0;
        val = 1;
        for ch = str
            if ch == '1'
                res = res + val
            end
            val = val .* 2;
        end
    end
end
