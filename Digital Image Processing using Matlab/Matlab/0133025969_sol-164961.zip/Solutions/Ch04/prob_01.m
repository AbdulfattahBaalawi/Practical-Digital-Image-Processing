clear
clc

% 1. Write a script to solve this problem. Assume you have a vector named D.
% Using iteration (for and/or while)  and conditionals (if and/or switch), 
% separate vector D into four vectors posEven, negEven, posOdd and negOdd.
% � posEven contains all of the positive even numbers in D.
% � negEven contains all of the negative even numbers in D.
% � posOdd contains all of the positive odd numbers in D.
% � negOdd contains all of the negative odd numbers in D.
% For example:
% if 
D = [-4,-3,-2,-1,0,1,2,3,4] %,
% posEven=[2,4], negEven=[-4,-2],
% posOdd=[1,3] and negOdd=[-3,-1]
posEven = []; posOdd = []; negEven = []; negOdd = [];
for val = D
    if val > 0
        if mod(val,2) == 0
            posEven = [posEven val]
        else
            posOdd = [posOdd val]
        end
    elseif val < 0
        if mod(val,2) == 0
            negEven = [negEven val]
        else
            negOdd = [negOdd val]
        end
    end
end
    


