clear
clc

% 6. A �yard� is a traditional English container. It is 36 inches long, and 
%  can be approximated by a 4-inch diameter glass sphere attached to a  
%  conical section whose narrow end is 1 inch in diameter, and whose wide
% end is 6 inches in diameter. Write a script to do the following:
%     a. ask the user for the height of the liquid in the yard, and
%     b. calculate the volume of liquid needed to fill the yard to that level.
%
%   formulae:
%
%    vol of partially filled sphere:
%          V = pi h^2(R - h/3)
%    vol of a cone:
%          V = 1/3 pi r^2 h
%                                    ..........   hi_r
%                            ......./          |
%          _ _        ....../ |                |
%         /   \ ...../ lo_r   |                |
%  ______|_____|______________|________________|___________________
%             2rs
%        <        h           > 
%  <        hc                > 
%  <                cone_overall               >
%  < lo_cone_h >
% given:
rs = 2 % sphere radius
lo_r = 1 % cone bottom
hi_r = 3 % cone top
ch = 32 % height of the cone above the sphere
taper = ch / (hi_r - lo_r) % taper of the cone
cone_overall = hi_r * taper
lo_cone_h = taper * lo_r
lo_cone_v = pi .* lo_r.^2 .* lo_cone_h ./ 3
quit = false
while ~quit
    h = input('liquid level: ');
    quit = h <= 0;
    if ~quit
        if h <= 2*rs
            V = pi .* h.^2 .* (rs - h./3);
        else
            V = 4.*pi.*rs.^3./3;
            hc = lo_cone_h + h - 2.*rs;
            hr = hc ./ taper;
            V = V + pi.* hr.^2 .* hc ./ 3 - lo_cone_v;
        end
        fprintf('Volume is %4.1f\n', V);
    end
end
