clear
clc

% 5. You have a friend who has too many clothes to store in her/his tiny  
%  wardrobe. Being a good friend, you offer to help to decide whether each  
%  piece of clothing is worth saving. You decide to write a script that  
%  will compute the value of each piece of clothing. A piece of clothing  
%  has five attributes that can used to determine its value.
% The attributes are:  
%     condition, color, price, number of matches, and comfort.  
%  Each attribute will be rated on a scale of 1-5. Write a script called  
%  clothes that will ask the user for the ratings for each attribute and  
%  store the result in a vector. The order of attributes in the vector is:  
%  [condition color price matches comfort]
% The script should compute a value between 0 and 100;  
%     100 represents a good piece of clothing while  
%       0 represents a bad piece of clothing.  
%  The points that should be given for each attribute are shown below:
%         Condition: 1=>0; 2=>5; 3=>10; 4=>15; 5=>20
%             Color: 1 => blue => 12; 2 => red => 2; 3 => pink => 15; 
%                    4 => yellow => 20; 5 => white => 12
%             Price: 1 => 8, 2�3 => 16, 4�5 => 20
%           Matches: 1�2 => 8, 3�5 => 19
% Comfort: 1 => 6, 2�3 => 13, 4�5 =>18
% Note: If a number other than 1�5 is assigned for one of the attributes,  
%  no points should be given.
quit = false;
values = [0 5 10 15 20;
          12 2 15 20 12;
          8 16 16 20 20;
          8 8 19 19 19;
          6 13 13 18 18]
while ~quit
    cond = input('condition: ','s');
    quit = cond < '1' || cond > '5';
    if ~quit
        vec(1) = cond - '0';
        vec(2) = input('color: ');
        vec(3) = input('price: ');
        vec(4) = input('matches: ');
        vec(5) = input('comfort: ');
        value = 0;
        for ndx = 1:5
            if vec(ndx) > 0 && vec(ndx) < 6
                value = value + values(ndx, vec(ndx));
            end
        end
        fprintf('value = %d\n', value)
    end
end
