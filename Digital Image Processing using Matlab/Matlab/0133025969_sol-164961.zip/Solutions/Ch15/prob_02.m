function test
    clc
    close all
% 2. Write a function, bestFit, that takes in a vector of x-coordinates 
%    and a vector of y-coordinates. Your function should fit a polynomial 
%    curve to the data. The degree of the polynomial should be the smallest 
%    degree polynomial with an average error (the average of the absolute 
%    value of the difference between the new ycoordinates and the original 
%    y-coordinates) less than 2. Your function should return:
%     � the vector of coefficients of your polynomial
%     � the vector of new y-coordinates which is the polynomial evaluated 
%       at the original x-coordinates, and
%     � the vector of the error magnitudes of your polynomial.
    xi = -12:0.1:12;
    yi = 10*(xi/6).^3 + 20*cos(xi);
%    Write a test program to provide reasonable data to your function 
%    and plot the original data (in blue), the curvefitted data (in green), 
%    and the error (in red) on one figure. Title your plot and label your 
%    axes accordingly, including a legend.
    plot(xi, yi)
    [coeff yp err] = bestFit(xi, yi);
    hold on
    plot(xi, yp, 'g')
    plot(xi, err, 'r')
    grid on
    legend({'original data','bestFit','error'})
end

function [coeff yp err] = bestFit(x, y)
    OK = false;
    order = 0;
    coeff = [];
    yp = [];
    err = [];
    while ~OK
        order = order + 1;
        coeff = polyfit(x, y, order);
        yp = polyval(coeff, x);
        err = yp - y;
        OK = mean(abs(err)) < 2;
    end
end

