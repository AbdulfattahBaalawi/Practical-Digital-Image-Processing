function test
    clc
    close all
% 6. Now that we used the derivative it only makes sense that you are 
%    going to write a function that finds integrals. Call your function  
%    find_integral. Your function should take in a vector of x and y values  
%    as Problem 15.5 does and should plot the integral and also return  
%    the total area under the function. You are to use the trapezoidal 
%    rule to find the integrals. For example:
    x=linspace(0,5,1000);
    y=2*x+5;
    area = find_integral(x,y)  % should return 50.0000
end

function area = find_integral(x, y)
    plot(x, y)
    int = cumtrapz(x, y);
    hold on
    plot(x, int, 'r')
    area = int(end) - int(1);
end
