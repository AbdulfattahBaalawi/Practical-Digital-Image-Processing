function test
    clc
    close all
    
    global x
    global y
% 5. Mathematically speaking, a critical point occurs when the derivative 
%    of a function equals zero. It is possible that a local minimum or a  
%    local maximum occurs at a critical point. A local minimum is a point  
%    where the function�s value to the left and right of it are larger,  
%    and a local maximum is a point where the function�s value to the left  
%    and right of it are smaller. You are going to write a function that  
%    finds the local minimum and maximum points of a set of data. Call  
%    the function find_points. It should take in vectors of x and y values  
%    and return two vectors. The first vector should contain the x values  
%    where the minimum points occur while the second vector should contain  
%    the x values where the maximum points occur. For example,
 x = linspace(-8,2,1000);
 y = x.^2+6*x+3;
[min_p max_p]=find_points(x,y) 
%    should return min_p = -3, max_p = []
plot(x, y)
hold on
plot(min_p, f(min_p), 'g*');
plot(max_p, f(max_p), 'r*');
figure
x = linspace(-5,5,1000);
y = x.^3-12*x;
[min_p max_p]=find_points(x,y)
%    should return: min_p = 2, max_p = -2
plot(x, y)
hold on
plot(min_p, f(min_p), 'g*');
plot(max_p, f(max_p), 'r*');
%    You should plot x and y to confirm the answers.
end

function [mn mx] = find_points(x, y)
    mn = [];
    mx = [];
    % find the derivative
    dydx = diff(y) ./ diff(x);
    mxp = (x(1:end-1) + x(2:end))/2;
    where = dydx(1:end-1).*dydx(2:end) <= 0;
    ndx = find(where);
    for ii = ndx
        x0 = findZero(x(ii), x(ii+1));
        if f(x(ii)) < f(x0)
            mn = [mn x0];
        else
            mx = [mx x0];
        end
    end
end


function res = findZero(t1, t2)
    % terminating Condition
    if (t2 - t1) < 0.00001
        res = t1;
    else
        tm = (t1 + t2) / 2;
        f1 = f(t1);
        fm = f(tm);
        if f1*fm <= 0
            res = findZero(t1, tm);
        else
            res = findZero(tm, t2);
        end
    end
end


function res = f(tv)
    global x
    global y
    res = spline(x, y, tv);
end

