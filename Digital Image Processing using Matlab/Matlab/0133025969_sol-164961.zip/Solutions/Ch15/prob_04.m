function test
    clc
% 4. Engineers often use tabulated data for various calculations. An 
%    important method that any good engineer should be able to apply 
%    to tabulated data is Interpolation. In thermodynamics, the properties 
%    of a gas can be known when two of its properties have been fixed. 
%    You are required to come up with a continuous function being given 
%    the tabulated data below measured where the pressure is 0.10 MPa:
%       Temperature (deg C) Specific Volume (cu meters / Kg)
table = ...
[ 99.63 1.694
    100 1.696
    120 1.793
    160 1.984
    200 2.172
    240 2.359
    280 2.546
    320 2.732
    360 2.917
    400 3.103
    440 3.288
    500 3.565];
% Write a function called lookup that consumes three parameters: the above 
%    table in an array, a number value and a logical control value getTemp. 
%    If getTemp is true, the function interpolates the value as a specific 
%    volume and returns the corresponding temperature. Otherwise, 
%    it interpolates the value as a temperature and returns the 
%    corresponding specific volume. Your function must not extrapolate the 
%    data (i.e., it should return NaN if the user tries to obtain values 
%    outside the range of the table values).
    fprintf('the temp at SG %5.2f is %5.1f\n', 3, lookup(table, 3, true))
    fprintf('the SG at temp %5.1f is %5.2f\n', 250, lookup(table, 250, false))
    fprintf('the temp at SG %5.2f is %5.1f\n', 3, lookup(table, 1, true))
    fprintf('the SG at temp %5.1f is %5.2f\n', 250, lookup(table, 750, false))
end

function res = lookup(table, val, getTemp)
    if getTemp
        res = interp1(table(:, 2)', table(:, 1)', val);
    else
        res = interp1(table(:, 1)', table(:, 2)', val);
    end
end


