clear
clc
% 4. Write a script that, when given a vector of numbers, nums, creates a 
% vector newNums containing every other element of the original vector, 
% starting with the first element. For example, if 
nums = [6 3 56 7 8 9 445 6 7 437 357 5 4 3] %, 
% newNums should be [6 56 8 445 7 357 4]. 
% Note: You must not simply hard-code the numbers into your answer;
% your script should work with any vector of numbers.
newNums = nums(1:2:end)
