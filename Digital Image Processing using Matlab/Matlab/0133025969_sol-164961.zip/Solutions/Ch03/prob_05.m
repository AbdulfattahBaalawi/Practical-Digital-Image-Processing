clear
clc
% 5. You are given a vector of test scores and wish to normalize these 
% scores by computing a new vector,  normTests, which will contain the 
% test scores on linear scale from 0 to 100. A zero still corresponds 
% to a zero, and the highest test score will correspond to 100. 
% For example, if 
tests = [90 45 76 21 85 97 91 84 79 67 76 72 89 95 55] %,
% normTests should be
% [92.78 46.39 78.35 21.65 87.63 100 93.81 86.6 ...
% 81.44 69.07 78.35 74.23 91.75 97.94 56.7];
maxv = max(tests);
normTests = tests .* 100 ./ maxv
