clear
clc
% 2. Write a script that performs the following exercises on vectors:
% a. You are given a vector vec, defined as: 
vec = [45 8 2 6 98 55 45 -48 75] 
% You decide that you don�t want the numbers with even values. 
% Write s script to remove all of the even numbers (i.e., 8, 2, 6, 98, &
% -48) from vec. You should alter the vector vec rather than storing your 
% answer in a new variable. Since your commands must work for any vector of 
% any length, you must not use direct entry.
vec = vec(mod(vec,2) > 0)
% b. Create a variable called vLength that holds the length of the vector vec  
% modified in part a. You should  use a built-in function to calculate the  
% value based on the vector itself.
vlength = length(vec)
% c. Create a variable called vSum that holds the sum of the elements in vector  
% vec. Do not just enter the value. You should use a built-in function to  
% calculate the value based on the vector itself.
vSum = sum(vec)
% d. Calculate the average of the values in the vector vec two ways. First,  
% use a built-in function to find the average of vec, then, use the results 
% from parts b and c to calculate the average of vec.
av1 = mean(vec)
av2 = vSum / vlength
% e. Create a variable called vProd that holds the product of the elements  
% in vector vec. You should use a built-in function to calculate the value  
% based on the vector itself.
vProd = prod(vec)
