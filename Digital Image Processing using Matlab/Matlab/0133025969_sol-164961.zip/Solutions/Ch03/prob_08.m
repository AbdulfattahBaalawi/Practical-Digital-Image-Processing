clear
clc
% 8. Write a script named arrayCollide that will combine two arrays, sort 
% them, and then return a new array of a  specified size. 
% Your script should process the following data:
% � A: a 2D array of any size
% � B: another 2D array that may be a different size from A
% � N: a number specifying the number of rows for the new array
% � M: a number specifying the number of columns for the new array.
% Your script should produce an array, res, of size N*M that contains the 
% first N*M elements of A and B and is sorted columnwise. 
% If N*M is larger than the total number of elements in A and B, you should 
% fill empty spots with 0.
% Test this script by writing another script that repeatedly sets the 
% values of A, B, M and N and then invokes your arrayCollide script. 
% You can then create as many test cases as you wish. 
% For example, if 
A = [1 2 3; 5 4 6]%,
B = [7 8; 9 10; 12 11]%, 
N = 3 % and 
M = 4 %, res will be
        % [1 4 7 10
         % 2 5 8 11
         % 3 6 9 12]
vec = sort([reshape(A, 1, prod(size(A))) reshape(B, 1, prod(size(B)))]);
vec = [vec zeros(1, N*M - length(vec))];
res = reshape(vec(1:N*M), N, M)
% Change N to 4, and res will be
% [1 5 9 0
% 2 6 10 0
% 3 7 11 0
% 4 8 12 0]
N = 4
vec = [vec zeros(1, N*M - length(vec))];
res = reshape(vec(1:N*M), N, M)
