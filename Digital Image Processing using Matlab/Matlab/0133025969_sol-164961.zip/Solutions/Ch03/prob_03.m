clear
clc
% 3. Write a script to solve the following problems using only vector operations:
% a. Assume you have two vectors named A1 and B1 of equal length and create  
% a vector C1 that combines A1 and B1 such that  
%  C1 = [A1(1) B1(1) A1(2) B1(2) . . . . A1(end) B1(end)]. 
% For example, if 
A1 = [2, 4, 8] % and 
B1 = [3, 9, 27] % , C1 should contain [2, 3, 4, 9, 8, 27]
C1(1:2:2*length(A1)) = A1;
C1(2:2:2*length(B1)) = B1
% b. Assume that you have two vectors named A2 and B2 of different lenghts.  
% Create a vector C2 that combines A2 and B2 in a manner similar to part a. 
% However, if you run out of elements in one of the vectors, C2 also contains  
% the elements remaining from the longer vector.  
% For example, if 
A2 = [1, 2, 3, 4, 5, 6] % and 
B2 = [10, 20, 30] %, then C2 = [1, 10, 2, 20, 3, 30, 4, 5, 6];
lm = min([length(A2) length(B2)]);
C2(1:2:2*lm) = A2(1:lm);
C2(2:2:2*lm) = B2(1:lm);
C2 = [C2 A2(lm+1:end) B2(lm+1:end)]
% if 
A2 = [1, 2, 3]%  and 
B2 = [10, 20, 30, 40, 50]% , then C2 = [1, 10, 2, 20, 3, 30, 40, 50]
lm = min([length(A2) length(B2)]);
C2 = [];
C2(1:2:2*lm) = A2(1:lm);
C2(2:2:2*lm) = B2(1:lm);
C2 = [C2 A2(lm+1:end) B2(lm+1:end)]
