clear
clc
% 7. Great news! You have just been selected to appear on Jeopardy this 
% fall. You decide that it might be to your advantage to generate an array 
% representing the values of the questions on the board.
% a. Write a script to generate the matrix jeopardy that consists of 
% 6 columns and 5 rows. The columns are all identical but the values of 
% the rows range from 200 to 1000 in equal increments.
col = (200:200:1000)'
jeopardy = [col col col col col col]
% b. Next, generate the matrix doubleJeopardy, which has the same dimensions 
% as jeopardy but whose values range from 400 to 2000.
doubleJeopardy = 2 .* jeopardy
% c. You�ve decided to go even one step further and practice for a round 
% that doesn�t even exist yet.  Generate the matrix squaredJeopardy that 
% contains each entry of the original jeopardy matrix squared.
squaredJeopardy = jeopardy .^ 2
