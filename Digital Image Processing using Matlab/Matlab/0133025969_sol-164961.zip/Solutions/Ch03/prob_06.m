clear
clc
% 6. Write a script that takes a vector of numbers, A, and return a new 
% vector B, containing the cubes of the positive numbers in A. 
% If a particular entry is negative, replace its cube with 0. 
% For example, if 
A = [1 2 -1 5 6 7 -4 3 -2 0] %,  B should be [1 8 0 125 216 343 0 27 0 0]
B = zeros(1, length(A))
B(A > 0) = A(A > 0) .^ 3
