clear
clc
% 1. For these exercises, do not use the direct entry method to construct the vectors.
% Write a script that does the following:
% a. Construct a vector containing all of the even numbers between 6 and 33, 
% inclusive of the end points. Store your answer in the variable evens. 
% (Note: 33 is not an even number)
evens = 6:2:33
% b. Construct a vector, threes, containing every third number starting with 
% 8 and ending at 38.
threes = 8:3:38
% c. Construct a vector, reverse, containing numbers starting at 20 and counting 
%  backwards by one to 10.
reverse = 20:-1:10
% d. Construct a vector, theta, containing 100 evenly spaced values between 0 and 2?.
theta = linspace(0, 2.*pi)
% e. Construct a vector, myZeros, containing 15 elements, all of which are zeros.
myZeros = zeros(1,15)
% f. Construct a vector, random, containing 15 randomly generated numbers between 1 and 12.
random = rand(1,15)*11+1
