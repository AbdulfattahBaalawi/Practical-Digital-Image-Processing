function test
    clc
% 2. This problem is about processing structure arrays. Write a function 
%    named structSort that sorts a structure array based on a given field  
%    that contains numerical values. Your function should take in a  
%    structure array and a string that should correspond to one of the  
%    fields of the structure array and return the original structure array 
%    sorted on the given field. It should check to be sure that the  
%    specified field name is in fact one of the fields of the structure  
%    array, and call the error(�) function if it is not.
%    Test your function by using the buildCDs script from Chapter 7,  
%    using the input function to specify the sorting field.
    buildCDs
    field = input('Which field? ','s');
    sorted_CDs = structSort(cds, field)
    vals = {sorted_CDs.(field)}
end

function sa = structSort(sa, field)
    if isfield(sa, field)
        it = sa(1).(field);
        if ischar(it) 
            it = {sa.(field)};
        else
            it = [sa.(field)];
        end
        [~, order] = sort(it);
        sa = sa(order);
    else
        error([field ' is not a field in this structure'])
    end
end
