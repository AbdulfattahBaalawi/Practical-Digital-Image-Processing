function test
    clc
% 1. The purpose if this problem is to write a set of functions that 
%    calculate the volume of a slant cylinder with an irregular pentagonal  
%    cross section shown in Figure 10.10. 
%    You will be given two vectors, x and y, containing the coordinates  
%    of the corners of the pentagon, and the value h, the vertical height  
%    of the cylinder. We will need to break this problem apart, writing  
%    functions to solve each part:
% a. The volume of the cylinder is the area of the pentagon multiplied by  
%    the vertical height; write a function polyvol(x, y, h) to solve this.
% b. The area of the pentagon is the sum of the areas of three triangles  
%    shown in Figure 10.11. So we need to write a function pent_area(x, y)  
%    that asks for the area of the three triangles and adds them together.
% c. Given the coordinates of the corners of a triangle, we need a function  
%    tri_area(x, y) to calculate the area of the triangle�see Figure 10.12.  
%    To compute the area of the triangle, we need the values of a, b, and c.  
%    So if we had the lengths of the lines, the area of the triangle is  
%    given by Heron�s formula:
%                  A = ?( s(s-a)(s-b)(s-c) )
%    where s is half the sum of a, b and c
% d. So we need a function tri_side(x, y) that computes the length of a line  
%    when given its end points.
% e. Then, we can put the pieces back together by calling the functions  
%    with the right parameters, and then build and test polyvol using the  
%    test cases provided.
    x = [1 2 3 4 2.5]
    y = [1 4 4 1 0]
    h = 4
    volume = polyvol(x, y, h)
end

function v = polyvol(x, y, h)
    v = pent_area(x, y) .* h;
end

function a = pent_area(x, y)
    a = tri_area(x([1 2 5]), y([1 2 5])) ...
      + tri_area(x([2 3 5]), y([2 3 5])) ...
      + tri_area(x([3 4 5]), y([3 4 5]));
end

function ar = tri_area(x, y)
    a = tri_side(x([1 2]), y([1 2]))
    b = tri_side(x([2 3]), y([2 3]))
    c = tri_side(x([3 1]), y([3 1]))
    s = (a + b + c) ./ 2;
    ar = s .* (s-a) .* (s-b) .* (s-c)
end

function side = tri_side(x, y)
    dx = x(2) - x(1);
    dy = y(2) - y(1);
    side = sqrt(dx.^2 + dy.^2);
end
