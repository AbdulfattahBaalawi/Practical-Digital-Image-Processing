function underground
    clc
    pic = imread('underground.jpg');
    imshow(pic)
end
