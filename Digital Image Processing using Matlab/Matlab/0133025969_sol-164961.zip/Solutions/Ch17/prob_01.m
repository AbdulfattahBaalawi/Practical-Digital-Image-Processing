% We would like to validate the assertion that the London Underground is 
% designed to have at most two train changes between any pair of stations.  
% Using the methodology of Section 17.2.3 and the picture in Figure 17.4,
% construct a graph representing the major routes in that system. You will  
% not need all the stations identified for this exercise � only one station  
%  a. write a function that will determine the number of train changes to  
%     travel between any pair of stations using a breadth-first search to  
%     minimize the number of changes.
% b. Iterate across every pair of stations and find the station pair with  
% the maximum number of train changes.
% Note:  a. since we could not obtain sufficient copyright permissions, Fig
%        17.4 is not the London Underground map.  It is included in this  
%        folder for reference
%        b. the solution to this problem is greatly simplified if we 
%        transform the problem such that the lines are the nodes of a
%        graph and the stations are edges!
function underground
    global node
    global Q 
    global station
    global max_changes
    
     line = {'Bakerloo', ...            % 1
             'Central', ...             % 2
             'Circle', ...              % 3
             'District', ...            % 4
             'East London', ...         % 5
             'Hammersmith & City', ...  % 6
             'Metropolitan', ...        % 7
             'Jubilee', ...             % 8
             'Northern', ...            % 9
             'Piccadilly', ...          % 10
             'Victoria', ...            % 11
             'Waterloo & City', ...     % 12
             'Docklands Light Rail'};   % 13
     station = {'Wembley Park', [7 8]           % 1
                'Euston', [9 11]                % 2
                'Finsbury Park', [10 11]        % 3
                'Stratford', [2 8 13]           % 4
                'Kings Cross/St Pancras', [3 6 7 9 11]  % 5
                'Warren Street', [10 11]        % 6
                'Baker Street', [1 3 6 7 8]     % 7
                'Edgware Road', [3 4 6]         % 8
                'Paddington', [1 3 4 6]         % 9
                'Rayners Lane', [7 10]          % 10
                'Ealing Broadway', [2 4]        % 11
                'Notting Hill Gate', [2 3 4]    % 12
                'Bond Street', [2 8]            % 13
                'Oxford Circus', [1 2 11]       % 14
                'Tottenham Court Road', [2 9]   % 15
                'Holborn', [2 10]               % 16
                'Moorgate', [3 6 7 9]          % 17
                'Liverpool Street', [2 3 6 7]   % 18
                'Mile End', [2 4 6]             % 19
                'Bow Road', [4 6 13]            % 20
                'West Ham', [4 6 8]             % 21
                'Barking', [4 6]                % 22
                'Bank/Monument', [2 3 4 12 13]  % 23
                'Tower Hill/Gateway', [3 4 13]  % 24
                'Aldgate East', [4 6]           % 25
                'Whitechapel', [4 5 6]          % 26
                'Shadwell', [5 13]              % 27
                'Canning Town', [8 13]          % 28
                'Canary Wharf', [8 13]          % 29
                'Canada Water', [5 8]           % 30
                'London Bridge', [8 9]          % 31
                'Ealing Common', [2 4]          % 32
                'Acton Town', [4 10]            % 33
                'Hammersmith', [4 6 10]         % 34
                'Barons Court', [4 10]          % 35
                'Earls Court', [4 10]           % 36
                'Gloucester Road', [3 4 10]     % 37
                'South Kensington', [3 4 10]    % 38
                'Green Park', [8 10 11]         % 39
                'Piccadilly Circus', [1 10]     % 40
                'Leicester Square', [9 10]      % 41
                'Charing Cross', [1 9]          % 42
                'Embankment', [1 3 4 9]         % 43
                'Victoria', [3 4 11]            % 44
                'Westminster', [3 4 8]          % 45
                'Waterloo', [1 8 9 12]          % 46
                'Elephant & Castle', [1 9]      % 47
                'Stockwell', [9 11]             % 48
                'Ealing Broadway', [2 4]        % 49
                'Finchley Road', [7 8]};        % 50
    clc
    % the stations are the nodes; we need to define all the edges
    for nodeIndex = 1:length(line)
        node(nodeIndex).name = line{nodeIndex};
        node(nodeIndex).links = [];
        node(nodeIndex).stations = {};
    end
    % now connect all the "edges" = the station links
    for stnIndex = 1:length(station)
        vec = station{stnIndex,2};
        for r = 1:length(vec)
           for c = (r+1):length(vec)
               addLink(vec(r), vec(c), stnIndex);
           end
        end
    end
    max_changes = 0;
    % iterate through all line combinations
    for iln = 1:length(node)
        for jln = (iln+1):length(node)
            getPath(iln, jln);
        end
    end
    fprintf('\n\nMaximum number of changes = %d\n', max_changes)
end

function getPath(from, to)
    global Q
    global node
    global station
    global max_changes
    
    fprintf('Path from the %s line to the %s line\n', ...
        node(from).name, node(to).name);
    Q = {};
    Q{1} = {{node(from), {}}};
    found = false;
    while ~isempty(Q) && ~found
        here = Q{1};
        Q = Q(2:end);
        theNode = here{1}{1};
        for ndx = 1:length(theNode.links)
            tondx = theNode.links(ndx);
            path = here{1}{2};
            toNode = node(tondx);
            path = [path {{theNode, ndx}}];
            if tondx == to
                lp = length(path);
                if lp > max_changes, max_changes = lp; end
                for kx = 1:lp
                    aNode = path{kx}{1};
                    jndx = path{kx}{2};
                    via = aNode.stations{jndx};
                    tgt = aNode.links(jndx);
                    fprintf('  %d. Change at ', kx)
                    for n = 1:length(via)
                        pt = via(n);
                        str = station{pt};
                        fprintf('%s', str)
                        if n < length(via)
                            fprintf(' or ')
                        end
                    end
                    fprintf(' - to the %s line\n', node(tgt).name)
                end
                found = true;
                break;
            else
                Q = [Q {{{toNode, path}}}];
            end
        end
    end
end

function addLink(a, b, stn)
% a and b are line numbers
% each of these lines needs a link to the other line at this station
    addTo(a, b, stn)
    addTo(b, a, stn)
end

function addTo(here, this, stn)
global node
    existing = node(here).links;
    if any(existing == this)
        where = find(existing == this);
        node(here).stations{where} = [node(here).stations{where} stn];
    else
        node(here).links = [node(here).links this];
        node(here).stations = [node(here).stations {stn}];
    end
end