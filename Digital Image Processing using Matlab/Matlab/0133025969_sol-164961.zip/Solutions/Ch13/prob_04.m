function test
clc
close all
% 4. Write a function called rotate that takes in an image array and a 
%    number. The number represents the number of times the function will 
%    rotate the image clockwise by 90 degrees. A negative number signifies 
%    counterclockwise rotation and a positive one signifies clockwise 
%    rotation.
    img = imread('buzz.jpg');
    imshow(img)
    for ndx = 1:4
        figure
        imshow(rotate(img,ndx))
    end
end

function img = rotate(img, N)
    N = mod(N, 4);
    switch N
        case 1
            img = permute(img,[2 1 3]);
            img = img(:, end:-1:1, :);
        case 2
            img = img(end:-1:1, end:-1:1, :);
        case 3
            img = permute(img,[2 1 3]);
            img = img(end:-1:1, :, :);
    end
end


