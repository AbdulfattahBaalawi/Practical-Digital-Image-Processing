clear
clc
close all
% 6. For this exercise, you will visit�at least in Matlab�a place you have 
%    always wanted to go.
% a. Find or take a picture of yourself with a plain background such as a  
%    green screen, using the JPEG image format. It would be a good idea not  
%    to wear the color of the background.
% b. Find a JPEG image of the place you want to go and decide on the  
%    rectangle in that scene where your image should appear. Save the width  
%    and height of the rectangle and the row and column of its top left
%    corner.
% c. Re-size your image to be the width and height of the rectangle.
% d. Use the color masking technique of section 13.4.2 to copy your image  
%    without the green screen into the selected rectangle of your dream  
%    scene.
dog = imread('dogOnFloor.jpg');
[rows cols junk] = size(dog)
rindex = floor(linspace(1, rows, 380));
cindex = floor(linspace(1, cols, 550));
dog = dog(rindex, cindex, :);
dog = dog(130:330, 100:470,:);
[drw, dcl, junk] = size(dog);
there = imread('mountains.jpg');
there = there(rindex, cindex, :);
% extract the field patch
prows = 320:360;
pcols = 400:470;
patch = there(prows, pcols, :);
[prw pcl junk] = size(patch);
% shrink dog to the size of the patch
dog = dog(floor(linspace(1, drw, prw)),floor(linspace(1, dcl, pcl)), :); 
% distinguish dog from floor
isDog = dog(:,:,3) > 66;
% copy the dog to the dogPatch
r = patch(:,:,1);
g = patch(:,:,2);
b = patch(:,:,3);
r(isDog) = dog(isDog);
g(isDog) = dog(isDog);
b(isDog) = dog(isDog);
dogPatch(:,:,1) = r;
dogPatch(:,:,2) = g;
dogPatch(:,:,3) = b;
thePatch = double(patch);
there(prows, pcols,:) = dogPatch;
imshow(there);
