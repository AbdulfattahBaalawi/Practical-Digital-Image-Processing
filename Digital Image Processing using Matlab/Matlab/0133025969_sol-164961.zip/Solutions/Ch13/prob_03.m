function test
clc
close all
% 3. You are provided an image and your job is to convert the full-sized 
%    image to a smaller one. Normally when image processing software is 
%    required to resize an image, a complex resizing algorithm is used to 
%    accomplish the conversion. We will attempt to duplicate this conversion. 
%    Write a function called resizeMe that takes in a string as an input 
%    corresponding to an image file name. The function should then resize 
%    the image to 1.414 times its original size in each dimension and 
%    display it. Additionally your function should use the built-in
%    function imwrite(...) to write the new image to a file. The name of the 
%    new file will be the original file name preceded by 'LG'. For example, 
%    if the original filename is called 'yellow_bird.jpg', the new file 
%    should be called 'LGyellow_bird.jpg'.
    resizeMe('buzz.jpg')
end

function resizeMe(name)
    img = imread(name);
    [rows cols ~] = size(img);
    nr = floor(linspace(1, rows, floor(1.414*rows)));
    nc = floor(linspace(1, cols, floor(1.414*cols)));
    img = img(nr, nc, :);
    imshow(img)
    imwrite(img, ['LG' name])
end

