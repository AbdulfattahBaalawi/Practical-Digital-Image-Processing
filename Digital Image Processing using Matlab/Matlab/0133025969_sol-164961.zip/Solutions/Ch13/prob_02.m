function test
clc
close all
% 2. An image could be scrambled by doing the following in order:
% a. multiple quadrant flips:
%    � top left quadrant becomes bottom right quadrant
%    � top right quadrant becomes bottom left quadrant
%    � bottom right quadrant becomes top left quadrant
%    � bottom left quadrant becomes top right quadrant
% b. The image is flipped upside down.
% c. The red values are swapped with the green values.
% d. The blue values are flipped left to right.
%    Write a function called imageScrambler that takes in an image array and a 
%    string. If the string is equal to 'scramble', your function should  
%    scramble the image according to the above method and return the  
%    modified image in array form. If the string is equal to 'unscramble',  
%    your function should unscramble the image by reversing the above method  
%    and return the modified array. Otherwise, your function should return  
%    the array untouched. You may assume that the image array provided will  
%    always contain an even number of rows and columns.
%    Test your solution by writing a script that reads a selected image, A,  
%    ensures that there is an even number of rows and columns, and test the  
%    scrambling and unscrambling the image.
    A = imread('buzz.jpg');
    [rows cols ~] = size(A);
    if mod(rows,2) > 0
        error('need even number of rows')
    end
    if mod(cols,2) > 0
        error('need even number of columns')
    end
    imshow(A)
    figure
    B = imageScrambler(A, 'scramble'); 
    imshow(B)
    figure
    C = imageScrambler(B, 'unscramble'); 
    imshow(C)
end

function A = imageScrambler(A, cmd)
    switch cmd
        case 'scramble'
            tl = A(    1:end/2,     1:end/2, :);
            tr = A(    1:end/2, end/2+1:end, :);
            bl = A(end/2+1:end,     1:end/2, :);
            br = A(end/2+1:end, end/2+1:end, :);
            A = [br bl; tr tl];         % a.
            A = A(end:-1:1,:,:);        % b.
            A = A(:,:,[2 1 3]);         % c.
            A(:,:,3) = A(:,end:-1:1,3); % d.
        case 'unscramble'
            A(:,:,3) = A(:,end:-1:1,3); % d.
            A = A(:,:,[2 1 3]);         % c.
            A = A(end:-1:1,:,:);        % b.
            tl = A(    1:end/2,     1:end/2, :);
            tr = A(    1:end/2, end/2+1:end, :);
            bl = A(end/2+1:end,     1:end/2, :);
            br = A(end/2+1:end, end/2+1:end, :);
            A = [br bl; tr tl];         % a.
    end
end

