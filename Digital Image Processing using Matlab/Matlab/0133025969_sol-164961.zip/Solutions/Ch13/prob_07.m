function test
clc
close all
% 7. Write a function called adjustImage that consumes the name of an image 
%    file and an angle in degrees and produces a new image rotated  
%    counter-clockwise by that number of degrees about the center of the  
%    original image.
% Your new image will be larger than the original image.
% Hint: the trick to this is to move each pixel from its current location  
%    (in polar coordinates, r - theta) to a new location on the new image.  
%    The new location is found by adding the rotation angle provided to  
%    the angular value, theta, of each pixel. Those pixels in the new image  
%    not occupied by a pixel will be black

% note: I fiddled with the problem spec a bit in order to get this rotation
%       demo to look good
    dog = imread('dogOnFloor.jpg');
    dog = dog(300:3:1100, 300:3:1400,:);
    imshow(dog)
    for deg = 1:360
        pause(0.001)
        new_dog = adjustImage(dog, deg);
        imshow(new_dog);
    end
end

function img1 = adjustImage(img, ang)
    [rows cols ~] = size(img);
    A = [cosd(ang) -sind(ang)
         sind(ang)  cosd(ang)];
    [rr cc] = meshgrid(1:rows,1:cols);  % image pixel locations
    V1(1,:) = reshape(rr, 1, rows*cols);
    V1(2,:) = reshape(cc, 1, rows*cols);
    V2 = A*V1;
    mv = min(V2');
    V2(1,:) = ceil(V2(1,:) - mv(1) + 1);
    V2(2,:) = ceil(V2(2,:) - mv(2) + 1);
    mx = max(V2');
    img1 = uint8(zeros(mx(1), mx(2), 3));
    for ndx = 1:rows*cols
        img1(V2(1,ndx), V2(2,ndx),:) = img(V1(1,ndx), V1(2,ndx),:);
    end 
end