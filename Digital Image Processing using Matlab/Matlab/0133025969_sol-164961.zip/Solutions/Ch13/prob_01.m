clear
clc
close all
% 1. As an introduction to image problems, perform the following 
%    manipulations:
% a. Find a suitable JPEG image file. Read it, display it and store the  
%    result in A.
A = imread('buzz.jpg');
imshow(A)
% b. Create a copy of A, flip the image from left to right, and display it  
%    in a new figure.
figure
imshow(A(:,end:-1:1,:))
% c. Create a copy of A, swap the values for red and blue, and display it  
%    in a new figure.
figure
imshow(A(:,:,[3 2 1]))
% d. Create a copy of A, stretch the image to 4 times its original size  
%    (twice as many rows and twice as many columns), and display it in a  
%    new figure.
figure
[rows cols ~] = size(A);
nr = floor(linspace(1, rows, 4*rows));
nc = floor(linspace(1, cols, 4*cols));
imshow(A(nr, nc, :))
% e. Create a copy of A and then shrink the image to 0.7 its original size  
%    in each dimension and display it in a new figure.
figure
nr = floor(linspace(1, rows, 0.7*rows));
nc = floor(linspace(1, cols, 0.7*cols));
imshow(A(nr, nc, :))

