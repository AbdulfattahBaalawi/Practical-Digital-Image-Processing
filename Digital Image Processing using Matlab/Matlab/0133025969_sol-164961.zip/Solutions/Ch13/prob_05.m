clear
clc
close all
% 5. We have obtained new intelligence that the Housing Department has 
%    plans to renovate all the rooms in the dorms with a new prototype. 
%    However, the prototype has been encoded into 3 separate images to 
%    avoid rival students finding out about it and thus seeking refuge here. 
%    Each image only contains one layer of color (e.g., 
%    roomScrambledRed.jpg only contains the Red layer). As a loyal student, 
%    it is your job to reconstruct a new image out of these 3 images.
% a. Create a script called room, and read the three layers using 'imread'. 
%    Create the new matrix ReconImage with the three layers and display it 
%    using 'imshow'.
% b. After detailed analysis of the image, you find that it is also 
%    scrambled. Using advanced crytography and whizbang mathematical 
%    formulas, you have come to the conclusion that the 4 quadrants of the
%    image have been re-arranged. Manipulate the composite image from part 
%    a. and re-arrange the pieces to form the proper image. 
%    Display it using subplot(...), below the first image.

ar = imread('roomRed.jpg');
ag = imread('roomGreen.jpg');
ab = imread('roomBlue.jpg');
ReconImage(:,:,1) = ar;
ReconImage(:,:,2) = ag;
ReconImage(:,:,3) = ab;
subplot(2,1,1)
imshow(ReconImage)
subplot(2,1,2)

tl = ReconImage(    1:end/2,     1:end/2, :);
tr = ReconImage(    1:end/2, end/2+1:end, :);
bl = ReconImage(end/2+1:end,     1:end/2, :);
br = ReconImage(end/2+1:end, end/2+1:end, :);
ReconImage = [tr bl; tl br]; 
imshow(ReconImage)




    


